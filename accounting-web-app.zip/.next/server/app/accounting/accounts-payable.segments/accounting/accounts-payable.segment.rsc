1:"$Sreact.fragment"
2:I[339756,["/_next/static/chunks/2dfurgh_m_xdi.js","/_next/static/chunks/1lrcnf05tis9c.js"],"default"]
3:I[837457,["/_next/static/chunks/2dfurgh_m_xdi.js","/_next/static/chunks/1lrcnf05tis9c.js"],"default"]
4:[]
0:{"rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"isPartial":false,"staleTime":300,"varyParams":"$W4","buildId":"HmLEBSiKhWF4bqD1Buj9g"}
