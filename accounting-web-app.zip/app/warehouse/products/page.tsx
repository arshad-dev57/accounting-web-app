'use client';

import { useState, useEffect, useCallback, useRef, useMemo } from 'react';
import Link from 'next/link';
import {
  Plus, Search, Edit, Trash2, Eye, Package, ChevronDown,
  X, Save, AlertCircle, Info, FileText, Truck,
  DollarSign, Box, Tag, Building2, Calendar, MapPin,
  Layers, Scale, Ruler, Award, Shield, Clock, Upload,
  Image as ImageIcon, Link as LinkIcon, Hash, Type, AlignLeft,
  Settings, Loader2, ChevronLeft, ChevronRight, Barcode,
  Camera, Download, Printer, CheckCircle, XCircle, ZoomIn,
  Thermometer, Package2, ShoppingCart, RotateCcw, Star,
  Globe, AlertTriangle, Archive, Boxes
} from 'lucide-react';
import { productService, Product, getProductId } from '../../api/product/route';
import { categoryService, Category } from '../../api/category/route';
import { supplierService, Supplier } from '../../api/supplier/route';
import { settingService } from '../../api/settings/route';
import { ProductTaxFields } from '../../../components/TaxRateSelect';
import QuickAddSelect from '../../../components/QuickAddSelect';
import { useLocation } from '@/lib/location-context';

// ============================================================
// BARCODE DISPLAY COMPONENT
// ============================================================
function BarcodeDisplay({ value, productName }: { value: string; productName: string }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [error, setError] = useState('');

  useEffect(() => {
    if (!value || !canvasRef.current) return;
    const loadJsBarcode = async () => {
      try {
        // @ts-ignore
        const JsBarcode = (await import('jsbarcode')).default;
        JsBarcode(canvasRef.current, value, {
          format: 'CODE128',
          width: 2,
          height: 60,
          displayValue: true,
          fontSize: 12,
          margin: 10,
          background: '#ffffff',
          lineColor: '#1a1a1a',
        });
      } catch (e) {
        setError('Barcode render failed');
      }
    };
    loadJsBarcode();
  }, [value]);

  const handleDownload = () => {
    if (!canvasRef.current) return;
    const link = document.createElement('a');
    link.download = `barcode-${productName}.png`;
    link.href = canvasRef.current.toDataURL('image/png');
    link.click();
  };

  const handlePrint = () => {
    if (!canvasRef.current) return;
    const dataUrl = canvasRef.current.toDataURL('image/png');
    const win = window.open('', '_blank');
    if (!win) return;
    win.document.write(`
      <html><head><title>Barcode - ${productName}</title>
      <style>body{display:flex;flex-direction:column;align-items:center;justify-content:center;min-height:100vh;font-family:sans-serif;}
      p{margin-top:8px;font-size:14px;color:#555;}</style></head>
      <body><img src="${dataUrl}" /><p>${productName}</p></body></html>
    `);
    win.document.close();
    win.print();
  };

  if (!value) return (
    <div className="flex flex-col items-center justify-center p-6 border-2 border-dashed border-gray-200 rounded-xl text-gray-400">
      <Barcode className="w-8 h-8 mb-2" />
      <p className="text-sm">No barcode assigned</p>
    </div>
  );

  return (
    <div className="flex flex-col items-center gap-3">
      {error ? (
        <p className="text-red-500 text-sm">{error}</p>
      ) : (
        <canvas ref={canvasRef} className="rounded-lg border border-gray-100" />
      )}
      <div className="flex gap-2">
        <button onClick={handleDownload} className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium border border-gray-200 rounded-lg hover:bg-gray-50 hover:border-[#014582] transition-all text-gray-600">
          <Download className="w-3.5 h-3.5" /> Download
        </button>
        <button onClick={handlePrint} className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium border border-gray-200 rounded-lg hover:bg-gray-50 hover:border-[#014582] transition-all text-gray-600">
          <Printer className="w-3.5 h-3.5" /> Print
        </button>
      </div>
    </div>
  );
}

// ============================================================
// BARCODE SCANNER COMPONENT
// ============================================================
function BarcodeScanner({ onScan, onClose }: { onScan: (value: string) => void; onClose: () => void }) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [scanning, setScanning] = useState(false);
  const [error, setError] = useState('');
  const [manualInput, setManualInput] = useState('');
  const stopRef = useRef<(() => void) | null>(null);

  useEffect(() => {
    let active = true;
    const startScanner = async () => {
      try {
        setScanning(true);
        // @ts-ignore
        const { BrowserMultiFormatReader } = await import('@zxing/browser');
        const codeReader = new BrowserMultiFormatReader();
        const devices = await BrowserMultiFormatReader.listVideoInputDevices();
        if (!devices.length) { setError('No camera found'); setScanning(false); return; }
        const deviceId = devices[devices.length - 1].deviceId;

        const controls = await codeReader.decodeFromVideoDevice(
          deviceId,
          videoRef.current!,
          (result: any, err: any) => {
            if (result && active) {
              active = false;
              onScan(result.getText());
            }
          }
        );
        stopRef.current = () => controls.stop();
      } catch (e: any) {
        setError(e.message || 'Camera access denied');
        setScanning(false);
      }
    };
    startScanner();
    return () => {
      active = false;
      stopRef.current?.();
    };
  }, [onScan]);

  const handleManualSubmit = () => {
    if (manualInput.trim()) {
      stopRef.current?.();
      onScan(manualInput.trim());
    }
  };

  return (
    <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl w-full max-w-md overflow-hidden shadow-2xl">
        <div className="flex items-center justify-between px-5 py-4 border-b border-gray-100">
          <div className="flex items-center gap-2">
            <Camera className="w-5 h-5 text-[#014582]" />
            <h3 className="text-base font-bold text-gray-800">Scan Barcode</h3>
          </div>
          <button onClick={() => { stopRef.current?.(); onClose(); }} className="p-1.5 hover:bg-gray-100 rounded-lg">
            <X className="w-5 h-5 text-gray-500" />
          </button>
        </div>
        <div className="p-5 space-y-4">
          {error ? (
            <div className="p-3 bg-red-50 border border-red-200 rounded-lg text-red-600 text-sm flex items-center gap-2">
              <AlertCircle className="w-4 h-4 flex-shrink-0" />
              {error}
            </div>
          ) : (
            <div className="relative rounded-xl overflow-hidden bg-black aspect-video">
              <video ref={videoRef} className="w-full h-full object-cover" />
              <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                <div className="w-48 h-24 border-2 border-[#014582] rounded-lg shadow-[0_0_0_9999px_rgba(0,0,0,0.4)]" />
              </div>
              {scanning && (
                <div className="absolute bottom-3 left-1/2 -translate-x-1/2 flex items-center gap-1.5 bg-black/60 text-white text-xs px-3 py-1.5 rounded-full">
                  <Loader2 className="w-3 h-3 animate-spin" /> Scanning...
                </div>
              )}
            </div>
          )}
          <div className="relative">
            <div className="absolute inset-0 flex items-center"><div className="w-full border-t border-gray-200" /></div>
            <div className="relative flex justify-center text-xs text-gray-400"><span className="bg-white px-2">or enter manually</span></div>
          </div>
          <div className="flex gap-2">
            <input
              type="text"
              placeholder="Type barcode..."
              value={manualInput}
              onChange={(e) => setManualInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleManualSubmit()}
              className="flex-1 px-3 py-2 border border-gray-200 rounded-lg text-sm focus:ring-2 focus:ring-[#014582] focus:border-transparent outline-none"
            />
            <button onClick={handleManualSubmit} className="px-4 py-2 bg-[#014582] text-white text-sm font-medium rounded-lg hover:bg-[#01366a] transition-all">
              Search
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

// ============================================================
// PRODUCT DETAIL VIEW
// ============================================================
function ProductDetail({ product, onClose, onEdit }: { product: Product; onClose: () => void; onEdit: () => void }) {
  const [activeTab, setActiveTab] = useState('overview');

  const tabs = [
    { id: 'overview', label: 'Overview', icon: Info },
    { id: 'pricing', label: 'Pricing & Stock', icon: DollarSign },
    { id: 'warehouse', label: 'Warehouse', icon: MapPin },
    { id: 'physical', label: 'Physical', icon: Ruler },
    { id: 'batch', label: 'Batch & Expiry', icon: Clock },
    { id: 'shipping', label: 'Shipping', icon: Truck },
    { id: 'barcode', label: 'Barcode', icon: Barcode },
  ];

  const stockStatus =
    product.currentStock === 0
      ? { label: 'Out of Stock', cls: 'bg-red-100 text-red-700', dot: 'bg-red-500' }
      : product.currentStock <= (product.minimumStock || 5)
      ? { label: 'Low Stock', cls: 'bg-orange-100 text-orange-700', dot: 'bg-orange-500' }
      : { label: 'In Stock', cls: 'bg-green-100 text-green-700', dot: 'bg-green-500' };

  const DetailRow = ({ label, value, mono = false }: { label: string; value?: any; mono?: boolean }) => (
    <div className="flex items-start justify-between py-2.5 border-b border-gray-50 last:border-0">
      <span className="text-xs font-medium text-gray-400 uppercase tracking-wider w-40 flex-shrink-0">{label}</span>
      <span className={`text-sm text-gray-800 text-right ${mono ? 'font-mono font-semibold' : 'font-medium'}`}>
        {value !== undefined && value !== null && value !== '' ? String(value) : <span className="text-gray-300">—</span>}
      </span>
    </div>
  );

  const Badge = ({ children, color = 'gray' }: { children: React.ReactNode; color?: string }) => {
    const colors: Record<string, string> = {
      gray: 'bg-gray-100 text-gray-600',
      purple: 'bg-purple-100 text-purple-700',
      green: 'bg-green-100 text-green-700',
      blue: 'bg-blue-100 text-blue-700',
      orange: 'bg-orange-100 text-orange-700',
      red: 'bg-red-100 text-red-700',
    };
    return (
      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold ${colors[color]}`}>
        {children}
      </span>
    );
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-40 flex items-start justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl w-full max-w-4xl my-4 shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="flex items-start justify-between px-6 py-5 border-b border-gray-100 bg-gradient-to-r from-[#014582]/5 to-transparent">
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 bg-[#014582]/10 rounded-xl flex items-center justify-center flex-shrink-0">
              <Package className="w-6 h-6 text-[#014582]" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-gray-900">{product.name}</h2>
              <div className="flex items-center gap-2 mt-1 flex-wrap">
                <span className="font-mono text-xs font-bold text-[#014582] bg-[#014582]/10 px-2 py-0.5 rounded">{product.sku}</span>
                <span className={`flex items-center gap-1 text-xs font-semibold px-2.5 py-0.5 rounded-full ${stockStatus.cls}`}>
                  <span className={`w-1.5 h-1.5 rounded-full ${stockStatus.dot}`} />
                  {stockStatus.label}
                </span>
                {product.productType && <Badge color="blue">{product.productType}</Badge>}
              </div>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button onClick={onEdit} className="flex items-center gap-1.5 px-4 py-2 bg-[#014582] text-white text-sm font-semibold rounded-lg hover:bg-[#01366a] transition-all">
              <Edit className="w-3.5 h-3.5" /> Edit
            </button>
            <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-lg transition-all">
              <X className="w-5 h-5 text-gray-500" />
            </button>
          </div>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-2 sm:grid-cols-4 divide-x divide-gray-100 border-b border-gray-100">
          {[
            { label: 'Cost Price', value: `Rs. ${Number(product.costPrice || 0).toLocaleString()}`, icon: DollarSign, color: 'text-blue-600' },
            { label: 'Selling Price', value: `Rs. ${Number(product.sellingPrice || 0).toLocaleString()}`, icon: ShoppingCart, color: 'text-green-600' },
            { label: 'Current Stock', value: `${Number(product.currentStock || 0).toLocaleString()} ${product.stockUnit || 'Pcs'}`, icon: Boxes, color: 'text-purple-600' },
            { label: 'Min Stock', value: `${Number(product.minimumStock || 0).toLocaleString()} ${product.stockUnit || 'Pcs'}`, icon: AlertTriangle, color: 'text-orange-600' },
          ].map(({ label, value, icon: Icon, color }) => (
            <div key={label} className="px-5 py-4">
              <div className="flex items-center gap-2 mb-1">
                <Icon className={`w-3.5 h-3.5 ${color}`} />
                <span className="text-xs text-gray-400 font-medium">{label}</span>
              </div>
              <p className={`text-base font-bold ${color}`}>{value}</p>
            </div>
          ))}
        </div>

        {/* Tabs */}
        <div className="flex overflow-x-auto border-b border-gray-100 px-4 gap-1">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button key={tab.id} onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2 px-4 py-3 text-sm font-medium border-b-2 transition-all whitespace-nowrap
                  ${isActive ? 'border-[#014582] text-[#014582]' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'}`}>
                <Icon className={`w-4 h-4 ${isActive ? 'text-[#014582]' : 'text-gray-400'}`} />
                {tab.label}
              </button>
            );
          })}
        </div>

        {/* Tab Content */}
        <div className="p-6 max-h-[50vh] overflow-y-auto">

          {/* ── OVERVIEW ── */}
          {activeTab === 'overview' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-1">
                <h4 className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-3">Basic Info</h4>
                <DetailRow label="Product Name" value={product.name} />
                <DetailRow label="SKU" value={product.sku} mono />
                <DetailRow label="Product Type" value={product.productType} />
                <DetailRow label="Category" value={product.categoryName} />
                <DetailRow label="Supplier" value={product.supplierName} />
                <DetailRow label="Brand" value={product.brand} />
                <DetailRow label="Model No." value={product.modelNumber} />
              </div>
              <div className="space-y-1">
                <h4 className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-3">Description</h4>
                {product.description ? (
                  <p className="text-sm text-gray-700 leading-relaxed bg-gray-50 rounded-xl p-4">{product.description}</p>
                ) : (
                  <p className="text-sm text-gray-300 italic">No description provided</p>
                )}
                {product.tags && (
                  <div className="pt-3">
                    <h4 className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Tags</h4>
                    <div className="flex flex-wrap gap-1.5">
                      {(Array.isArray(product.tags) ? product.tags : (product.tags ? String(product.tags).split(',') : [])).map((tag: string, i: number) => (
                        <span key={i} className="text-xs bg-[#014582]/10 text-[#014582] font-medium px-2 py-0.5 rounded-full">{tag.trim()}</span>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* ── PRICING & STOCK ── */}
          {activeTab === 'pricing' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h4 className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-3">Pricing</h4>
                <DetailRow label="Cost Price" value={`Rs. ${Number(product.costPrice || 0).toLocaleString()}`} />
                <DetailRow label="Selling Price" value={`Rs. ${Number(product.sellingPrice || 0).toLocaleString()}`} />
                <DetailRow label="Landing Cost" value={product.landingCost ? `Rs. ${Number(product.landingCost).toLocaleString()}` : undefined} />
                <DetailRow label="Currency" value={product.currency || 'PKR'} />
                <DetailRow label="Tax Rate" value={product.taxRate ? `${product.taxRate}%` : undefined} />
                <DetailRow label="Tax Type" value={product.taxType} />
                {product.costPrice && product.sellingPrice && (
                  <div className="mt-4 p-3 bg-green-50 border border-green-100 rounded-xl">
                    <p className="text-xs text-green-600 font-medium mb-0.5">Profit Margin</p>
                    <p className="text-lg font-bold text-green-700">
                      {(((Number(product.sellingPrice) - Number(product.costPrice)) / Number(product.costPrice)) * 100).toFixed(1)}%
                      <span className="text-sm font-normal ml-2 text-green-600">
                        (Rs. {(Number(product.sellingPrice) - Number(product.costPrice)).toLocaleString()})
                      </span>
                    </p>
                  </div>
                )}
              </div>
              <div>
                <h4 className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-3">Stock Levels</h4>
                <DetailRow label="Stock Unit" value={product.stockUnit} />
                <DetailRow label="Stock at this location" value={`${Number(product.currentStock || 0).toLocaleString()} ${product.stockUnit || ''}`} />
                {product.companyStock != null ? (
                  <DetailRow label="All locations (total)" value={`${Number(product.companyStock).toLocaleString()} ${product.stockUnit || ''}`} />
                ) : null}
                <DetailRow label="Minimum Stock" value={`${Number(product.minimumStock || 0).toLocaleString()} ${product.stockUnit || ''}`} />
                <DetailRow label="Maximum Stock" value={product.maximumStock ? `${Number(product.maximumStock).toLocaleString()} ${product.stockUnit || ''}` : undefined} />
                <DetailRow label="Reorder Point" value={product.reorderPoint} />
                <DetailRow label="Lead Time" value={product.leadTime ? `${product.leadTime} days` : undefined} />
                {product.maximumStock && product.currentStock !== undefined && (
                  <div className="mt-4">
                    <div className="flex justify-between text-xs text-gray-500 mb-1">
                      <span>Stock Level</span>
                      <span>{Math.round((Number(product.currentStock) / Number(product.maximumStock)) * 100)}%</span>
                    </div>
                    <div className="w-full h-2.5 bg-gray-100 rounded-full overflow-hidden">
                      <div
                        className={`h-full rounded-full transition-all ${
                          product.currentStock <= (product.minimumStock || 5) ? 'bg-orange-400' :
                          product.currentStock === 0 ? 'bg-red-500' : 'bg-green-500'
                        }`}
                        style={{ width: `${Math.min(100, (Number(product.currentStock) / Number(product.maximumStock)) * 100)}%` }}
                      />
                    </div>
                    <div className="flex justify-between text-xs text-gray-400 mt-1">
                      <span>0</span><span>Min: {product.minimumStock}</span><span>Max: {product.maximumStock}</span>
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* ── WAREHOUSE ── */}
          {activeTab === 'warehouse' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h4 className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-3">Location</h4>
                <DetailRow label="Rack Location" value={product.location || product.rackLocation} />
                <DetailRow label="Zone" value={product.zone} />
                <DetailRow label="Pallet Number" value={product.palletNumber} />
                <DetailRow label="Shelf Number" value={product.shelfNumber} />
              </div>
              <div>
                <h4 className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-3">Storage</h4>
                <DetailRow label="Storage Condition" value={product.storageCondition} />
                <DetailRow label="Temp Min" value={product.tempMin !== undefined ? `${product.tempMin}°C` : undefined} />
                <DetailRow label="Temp Max" value={product.tempMax !== undefined ? `${product.tempMax}°C` : undefined} />
              </div>
            </div>
          )}

          {/* ── PHYSICAL ── */}
          {activeTab === 'physical' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h4 className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-3">Dimensions & Weight</h4>
                <DetailRow label="Weight" value={product.weight ? `${product.weight} ${product.weightUnit || 'KG'}` : undefined} />
                <DetailRow label="Length" value={product.length ? `${product.length} ${product.dimensionUnit || 'cm'}` : undefined} />
                <DetailRow label="Width" value={product.width ? `${product.width} ${product.dimensionUnit || 'cm'}` : undefined} />
                <DetailRow label="Height" value={product.height ? `${product.height} ${product.dimensionUnit || 'cm'}` : undefined} />
              </div>
              <div>
                <h4 className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-3">Attributes</h4>
                <DetailRow label="Color" value={product.color} />
                <DetailRow label="Size" value={product.size} />
                <DetailRow label="Material" value={product.material} />
                <DetailRow label="Finish" value={product.finish} />
              </div>
            </div>
          )}

          {/* ── BATCH & EXPIRY ── */}
          {activeTab === 'batch' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h4 className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-3">Tracking Flags</h4>
                {[
                  { label: 'Has Expiry', value: product.hasExpiry },
                  { label: 'Batch Managed', value: product.isBatchManaged },
                  { label: 'Serial Managed', value: product.isSerialManaged },
                  { label: 'Expiry Managed', value: product.isExpiryManaged },
                  { label: 'Bulk Managed', value: product.isBulkManaged },
                  { label: 'Individual Tracking', value: product.hasIndividualTracking },
                ].map(({ label, value }) => (
                  <div key={label} className="flex items-center justify-between py-2.5 border-b border-gray-50 last:border-0">
                    <span className="text-xs font-medium text-gray-400 uppercase tracking-wider">{label}</span>
                    {value ? (
                      <span className="flex items-center gap-1 text-xs font-semibold text-green-700 bg-green-100 px-2 py-0.5 rounded-full">
                        <CheckCircle className="w-3 h-3" /> Yes
                      </span>
                    ) : (
                      <span className="flex items-center gap-1 text-xs font-semibold text-gray-500 bg-gray-100 px-2 py-0.5 rounded-full">
                        <XCircle className="w-3 h-3" /> No
                      </span>
                    )}
                  </div>
                ))}
              </div>
              <div>
                <h4 className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-3">Dates & Batch</h4>
                <DetailRow label="Batch Number" value={product.batchNumber} mono />
                <DetailRow label="Mfg. Date" value={product.manufacturingDate ? new Date(product.manufacturingDate).toLocaleDateString() : undefined} />
                <DetailRow label="Expiry Date" value={product.expiryDate ? new Date(product.expiryDate).toLocaleDateString() : undefined} />
                <DetailRow label="Shelf Life" value={product.shelfLife ? `${product.shelfLife} days` : undefined} />
                <DetailRow label="Bulk Unit" value={product.bulkUnit} />
                <DetailRow label="Default Batch Qty" value={product.defaultBatchQuantity} />
              </div>
            </div>
          )}

          {/* ── SHIPPING ── */}
          {activeTab === 'shipping' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h4 className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-3">Shipping Info</h4>
                <DetailRow label="HS Code" value={product.hsCode} mono />
                <DetailRow label="Country of Origin" value={product.countryOfOrigin} />
                <DetailRow label="Shipping Class" value={product.shippingClass} />
                <DetailRow label="Freight Class" value={product.freightClass} />
                <DetailRow label="Stacking Limit" value={product.stackingLimit} />
              </div>
              <div>
                <h4 className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-3">Safety & Returns</h4>
                <div className="flex items-center justify-between py-2.5 border-b border-gray-50">
                  <span className="text-xs font-medium text-gray-400 uppercase tracking-wider">Dangerous Goods</span>
                  {product.dangerousGoods ? (
                    <Badge color="red">⚠ Yes</Badge>
                  ) : (
                    <Badge color="green">Safe</Badge>
                  )}
                </div>
                <DetailRow label="UN Number" value={product.unNumber} mono />
                <DetailRow label="Handling" value={product.handlingInstructions} />
                <DetailRow label="Warranty" value={product.warrantyPeriod ? `${product.warrantyPeriod} ${product.warrantyUnit || 'Months'}` : undefined} />
                <div className="flex items-center justify-between py-2.5 border-b border-gray-50">
                  <span className="text-xs font-medium text-gray-400 uppercase tracking-wider">Returnable</span>
                  {product.isReturnable ? (
                    <Badge color="green">Yes — {product.returnDays || 7} days</Badge>
                  ) : (
                    <Badge color="red">No</Badge>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* ── BARCODE ── */}
          {activeTab === 'barcode' && (
            <div className="flex flex-col items-center gap-6">
              <div className="w-full max-w-sm">
                <h4 className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-4 text-center">Barcode</h4>
                <BarcodeDisplay
                  value={product.barcode?.number || product.barcodeNumber || product.sku}
                  productName={product.name}
                />
                <div className="mt-4 space-y-1">
                  <DetailRow label="Barcode No." value={product.barcode?.number || product.barcodeNumber || product.sku} mono />
                  <DetailRow label="Format" value="CODE128" />
                  <DetailRow label="SKU" value={product.sku} mono />
                </div>
              </div>
            </div>
          )}

        </div>
      </div>
    </div>
  );
}

// ============================================================
// PRODUCT LIST VIEW
// ============================================================
function ProductList({
  products, loading, pagination, searchTerm, setSearchTerm,
  selectedCategory, setSelectedCategory, selectedStatus, setSelectedStatus,
  onPageChange, onAddClick, onEditClick, onDeleteClick, onViewClick,
  onScanClick, categories, locationName,
}: {
  products: Product[];
  loading: boolean;
  pagination: { page: number; limit: number; total: number; pages: number; hasNext: boolean; hasPrev: boolean };
  searchTerm: string;
  setSearchTerm: (val: string) => void;
  selectedCategory: string;
  setSelectedCategory: (val: string) => void;
  selectedStatus: string;
  setSelectedStatus: (val: string) => void;
  onPageChange: (page: number) => void;
  onAddClick: () => void;
  onEditClick: (product: Product) => void;
  onDeleteClick: (id: string) => void;
  onViewClick: (product: Product) => void;
  onScanClick: () => void;
  categories: Category[];
  locationName?: string;
}) {
  const statusOptions = [
    { label: 'All Products', value: 'all' },
    { label: 'In Stock (here)', value: 'in' },
    { label: 'Out of Stock (here)', value: 'out' },
    { label: 'Low Stock (here)', value: 'low' },
  ];

  return (
    <div className="space-y-4 md:space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <h2 className="text-xl md:text-2xl font-bold text-gray-800 flex items-center gap-2">
          <Package className="w-5 h-5 md:w-6 md:h-6 text-[#014582]" />
          Products
          <span className="text-xs md:text-sm font-normal text-gray-400 ml-1 md:ml-2">({pagination.total} items)</span>
        </h2>
        <div className="flex flex-wrap items-center gap-2 md:gap-3">
          <button onClick={onScanClick} className="flex items-center gap-1.5 md:gap-2 px-3 md:px-4 py-1.5 md:py-2 border border-gray-200 rounded-lg text-xs md:text-sm font-medium text-gray-600 hover:bg-gray-50 hover:border-[#014582] transition-all">
            <Camera className="w-3.5 h-3.5 md:w-4 md:h-4" /> Scan
          </button>
          <Link href="/warehouse/product-settings" className="flex items-center gap-1.5 md:gap-2 px-3 md:px-4 py-1.5 md:py-2 border border-gray-200 rounded-lg text-xs md:text-sm font-medium text-gray-600 hover:bg-gray-50 hover:border-[#014582] transition-all">
            <Settings className="w-3.5 h-3.5 md:w-4 md:h-4" /> Settings
          </Link>
          <button onClick={onAddClick} className="flex items-center gap-1.5 md:gap-2 px-3 md:px-4 py-1.5 md:py-2 bg-[#014582] text-white rounded-lg text-xs md:text-sm font-semibold hover:bg-[#01366a] transition-all shadow-lg shadow-[#014582]/25">
            <Plus className="w-3.5 h-3.5 md:w-4 md:h-4" /> Add Product
          </button>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-3 md:p-4">
        <div className="flex flex-col sm:flex-row flex-wrap gap-3 md:gap-4">
          <div className="flex-1 min-w-[150px] md:min-w-[200px] relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 md:w-4 md:h-4 text-gray-400" />
            <input type="text" placeholder="Search products..." value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-8 md:pl-9 pr-3 md:pr-4 py-1.5 md:py-2 border border-gray-200 rounded-lg text-xs md:text-sm focus:ring-2 focus:ring-[#014582] focus:border-transparent outline-none" />
          </div>
          <div className="relative flex-1 sm:flex-none min-w-[120px]">
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="appearance-none w-full px-3 md:px-4 py-1.5 md:py-2 pr-8 md:pr-10 border border-gray-200 rounded-lg text-xs md:text-sm focus:ring-2 focus:ring-[#014582] focus:border-transparent outline-none bg-gray-50"
            >
              <option value="all">All Categories</option>
              {categories
                .filter((cat) => {
                  const parent = cat.parentId;
                  return parent == null || parent === '';
                })
                .map((cat) => {
                const id = cat.id || (cat as any)._id || '';
                return (
                  <option key={id || cat.name} value={id}>
                    {cat.name}
                  </option>
                );
              })}
            </select>
            <ChevronDown className="absolute right-2 md:right-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 md:w-4 md:h-4 text-gray-400 pointer-events-none" />
          </div>
          <div className="relative flex-1 sm:flex-none min-w-[100px]">
            <select
              value={selectedStatus}
              onChange={(e) => setSelectedStatus(e.target.value)}
              className="appearance-none w-full px-3 md:px-4 py-1.5 md:py-2 pr-8 md:pr-10 border border-gray-200 rounded-lg text-xs md:text-sm focus:ring-2 focus:ring-[#014582] focus:border-transparent outline-none bg-gray-50"
            >
              {statusOptions.map((status) => (
                <option key={status.value} value={status.value}>
                  {status.label}
                </option>
              ))}
            </select>
            <ChevronDown className="absolute right-2 md:right-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 md:w-4 md:h-4 text-gray-400 pointer-events-none" />
          </div>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-xs md:text-sm">
            <thead>
              <tr className="bg-gray-50 border-b border-gray-100">
                <th className="text-left px-3 md:px-6 py-2 md:py-3 text-[10px] md:text-xs font-semibold text-gray-500 uppercase tracking-wider">SKU</th>
                <th className="text-left px-3 md:px-6 py-2 md:py-3 text-[10px] md:text-xs font-semibold text-gray-500 uppercase tracking-wider">Product Name</th>
                <th className="text-left px-3 md:px-6 py-2 md:py-3 text-[10px] md:text-xs font-semibold text-gray-500 uppercase tracking-wider hidden sm:table-cell">Category</th>
                <th className="text-left px-3 md:px-6 py-2 md:py-3 text-[10px] md:text-xs font-semibold text-gray-500 uppercase tracking-wider hidden md:table-cell">Supplier</th>
                <th className="text-left px-3 md:px-6 py-2 md:py-3 text-[10px] md:text-xs font-semibold text-gray-500 uppercase tracking-wider">Price</th>
                <th className="text-left px-3 md:px-6 py-2 md:py-3 text-[10px] md:text-xs font-semibold text-gray-500 uppercase tracking-wider hidden lg:table-cell">
                  Stock{locationName ? ` (${locationName})` : ''}
                </th>
                <th className="text-left px-3 md:px-6 py-2 md:py-3 text-[10px] md:text-xs font-semibold text-gray-500 uppercase tracking-wider">Status</th>
                <th className="text-left px-3 md:px-6 py-2 md:py-3 text-[10px] md:text-xs font-semibold text-gray-500 uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr><td colSpan={8} className="text-center py-8 md:py-12">
                  <Loader2 className="w-6 h-6 md:w-8 md:h-8 mx-auto text-[#014582] animate-spin" />
                  <p className="mt-2 text-xs md:text-sm text-gray-500">Loading...</p>
                </td></tr>
              ) : products.length === 0 ? (
                <tr><td colSpan={8} className="text-center py-8 md:py-12 text-gray-400">
                  <Package className="w-8 h-8 md:w-12 md:h-12 mx-auto mb-2 md:mb-3 text-gray-300" />
                  <p className="text-sm md:text-lg font-medium text-gray-500">No products found</p>
                  <p className="text-xs md:text-sm text-gray-400">Try adjusting your search or filters</p>
                </td></tr>
              ) : (
                products.map((product) => (
                  <tr key={product.id} className="border-b border-gray-50 hover:bg-gray-50 transition-colors">
                    <td className="px-3 md:px-6 py-2 md:py-3 font-mono text-[10px] md:text-xs font-semibold text-gray-700">{product.sku}</td>
                    <td className="px-3 md:px-6 py-2 md:py-3 font-medium text-gray-800 text-xs md:text-sm">{product.name}</td>
                    <td className="px-3 md:px-6 py-2 md:py-3 text-gray-600 text-xs md:text-sm hidden sm:table-cell">{product.categoryName || '-'}</td>
                    <td className="px-3 md:px-6 py-2 md:py-3 text-gray-600 text-xs md:text-sm hidden md:table-cell">{product.supplierName || '-'}</td>
                    <td className="px-3 md:px-6 py-2 md:py-3 font-semibold text-gray-700 text-xs md:text-sm">Rs. {Number(product.sellingPrice).toLocaleString()}</td>
                    <td className="px-3 md:px-6 py-2 md:py-3 text-gray-600 text-xs md:text-sm hidden lg:table-cell">
                      {Number(product.currentStock || 0).toLocaleString()}
                    </td>
                    <td className="px-3 md:px-6 py-2 md:py-3">
                      <span className={`text-[8px] md:text-xs font-semibold px-1.5 md:px-2.5 py-0.5 md:py-1 rounded-full ${
                        product.currentStock === 0 ? 'bg-red-100 text-red-700' :
                        product.currentStock <= (product.minimumStock || 5) ? 'bg-orange-100 text-orange-700' :
                        'bg-green-100 text-green-700'
                      }`}>
                        {product.currentStock === 0 ? 'Out of Stock' :
                         product.currentStock <= (product.minimumStock || 5) ? 'Low Stock' : 'In Stock'}
                      </span>
                    </td>
                    <td className="px-3 md:px-6 py-2 md:py-3">
                      <div className="flex items-center gap-1 md:gap-2">
                        <button onClick={() => onViewClick(product)} className="p-1 md:p-1.5 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-all" title="View Detail">
                          <Eye className="w-3.5 h-3.5 md:w-4 md:h-4" />
                        </button>
                        <button onClick={() => onEditClick(product)} className="p-1 md:p-1.5 text-gray-400 hover:text-yellow-600 hover:bg-yellow-50 rounded-lg transition-all" title="Edit">
                          <Edit className="w-3.5 h-3.5 md:w-4 md:h-4" />
                        </button>
                        <button onClick={() => {
                          console.log('🔵 [Delete button clicked] Product object:', product);
                          console.log('🔵 [Delete button clicked] Product ID:', product.id);
                          if (!product.id) {
                            console.error('❌ [Delete button clicked] Product ID is missing!');
                            alert('Product ID is missing, cannot delete');
                            return;
                          }
                          onDeleteClick(product.id);
                        }} className="p-1 md:p-1.5 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-all" title="Delete">
                          <Trash2 className="w-3.5 h-3.5 md:w-4 md:h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {pagination && pagination.pages > 1 && (
        <div className="flex flex-col xs:flex-row items-center justify-between gap-3 bg-white rounded-xl shadow-sm border border-gray-100 p-3 md:p-4">
          <p className="text-[10px] md:text-sm text-gray-500 text-center xs:text-left">
            Showing {(pagination.page - 1) * pagination.limit + 1} –{' '}
            {Math.min(pagination.page * pagination.limit, pagination.total)} of {pagination.total} products
          </p>
          <div className="flex gap-1 md:gap-2">
            <button onClick={() => onPageChange(pagination.page - 1)} disabled={!pagination.hasPrev} className="p-1.5 md:p-2 border border-gray-200 rounded-lg hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed">
              <ChevronLeft className="w-3.5 h-3.5 md:w-4 md:h-4" />
            </button>
            <span className="px-2 md:px-4 py-1 md:py-2 bg-[#014582]/10 text-[#014582] font-semibold rounded-lg text-xs md:text-sm">
              {pagination.page} / {pagination.pages}
            </span>
            <button onClick={() => onPageChange(pagination.page + 1)} disabled={!pagination.hasNext} className="p-1.5 md:p-2 border border-gray-200 rounded-lg hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed">
              <ChevronRight className="w-3.5 h-3.5 md:w-4 md:h-4" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

// ============================================================
// CREATE/EDIT PRODUCT FORM (TAB-BASED)
// ============================================================
function ProductForm({
  editingProduct, onCancel, onSuccess, categories, suppliers, settingsData, loadingSettings,
  locationId,
  onCategoryCreated,
  onSupplierCreated,
  onSettingCreated,
}: {
  editingProduct?: Product | null;
  onCancel: () => void;
  onSuccess: () => void;
  categories: Category[];
  suppliers: Supplier[];
  settingsData: Record<string, any[]>;
  loadingSettings: boolean;
  locationId?: string;
  onCategoryCreated?: (cat: Category) => void;
  onSupplierCreated?: (sup: Supplier) => void;
  onSettingCreated?: (settingCategory: string, item: any) => void;
}) {
  const categoryList = Array.isArray(categories)
    ? categories.filter((c) => {
        const parent = c.parentId;
        return parent == null || parent === '' || parent === undefined;
      })
    : [];
  const supplierList = Array.isArray(suppliers) ? suppliers : [];
  const isEditing = !!editingProduct;

  const [activeTab, setActiveTab] = useState('basic');
  const [loadingSubs, setLoadingSubs] = useState(false);
  const [formData, setFormData] = useState({
    name: editingProduct?.name || '',
    sku: editingProduct?.sku || '',
    barcode: editingProduct?.barcode?.number || editingProduct?.barcodeNumber || '',
    productType: editingProduct?.productType || '',
    description: editingProduct?.description || '',
    tags: Array.isArray(editingProduct?.tags) ? editingProduct!.tags!.join(', ') : (editingProduct?.tags ? String(editingProduct.tags) : ''),
    costPrice: editingProduct?.costPrice || '',
    sellingPrice: editingProduct?.sellingPrice || '',
    landingCost: editingProduct?.landingCost || '',
    currency: editingProduct?.currency || editingProduct?.currencyCode || 'PKR',
    taxRate: editingProduct?.taxRate || '',
    taxType: editingProduct?.taxType || editingProduct?.taxTypeName || '',
    stockUnit: editingProduct?.stockUnit || editingProduct?.stockUnitName || '',
    currentStock: editingProduct?.currentStock || '',
    minimumStock: editingProduct?.minimumStock || '',
    maximumStock: editingProduct?.maximumStock || '',
    category: editingProduct?.categoryId || '',
    subCategory: '',
    brand: editingProduct?.brand || editingProduct?.brandName || '',
    modelNumber: editingProduct?.modelNumber || '',
    supplier: editingProduct?.supplierId || '',
    supplierSku: editingProduct?.supplierSku || '',
    leadTime: editingProduct?.leadTime ?? editingProduct?.leadTimeDays ?? '',
    reorderPoint: editingProduct?.reorderPoint || '',
    rackLocation: editingProduct?.rackLocation || editingProduct?.location || '',
    zone: editingProduct?.zone || editingProduct?.zoneName || '',
    palletNumber: editingProduct?.palletNumber || '',
    shelfNumber: editingProduct?.shelfNumber || '',
    storageCondition: editingProduct?.storageCondition || editingProduct?.storageConditionName || '',
    tempMin: editingProduct?.tempMin ?? editingProduct?.temperatureMin ?? '',
    tempMax: editingProduct?.tempMax ?? editingProduct?.temperatureMax ?? '',
    weight: editingProduct?.weight || '',
    weightUnit: editingProduct?.weightUnit || editingProduct?.weightUnitName || '',
    length: editingProduct?.length || '',
    width: editingProduct?.width || '',
    height: editingProduct?.height || '',
    dimensionUnit: editingProduct?.dimensionUnit || editingProduct?.dimensionUnitName || '',
    color: editingProduct?.color || '',
    size: editingProduct?.size || '',
    material: editingProduct?.material || '',
    finish: editingProduct?.finish || '',
    hasExpiry: !!editingProduct?.hasExpiry,
    isBatchManaged: !!editingProduct?.isBatchManaged,
    isSerialManaged: !!editingProduct?.isSerialManaged,
    isExpiryManaged: !!editingProduct?.isExpiryManaged,
    expiryDate: editingProduct?.expiryDate ? String(editingProduct.expiryDate).slice(0, 10) : '',
    manufacturingDate: editingProduct?.manufacturingDate ? String(editingProduct.manufacturingDate).slice(0, 10) : '',
    batchNumber: editingProduct?.batchNumber || '',
    shelfLife: editingProduct?.shelfLife ?? editingProduct?.shelfLifeDays ?? '',
    hsCode: editingProduct?.hsCode || '',
    countryOfOrigin: editingProduct?.countryOfOrigin || editingProduct?.countryOfOriginName || 'Pakistan',
    shippingClass: editingProduct?.shippingClass || '',
    freightClass: editingProduct?.freightClass || '',
    stackingLimit: editingProduct?.stackingLimit || '',
    dangerousGoods: !!editingProduct?.dangerousGoods,
    unNumber: editingProduct?.unNumber || '',
    handlingInstructions: editingProduct?.handlingInstructions || '',
    warrantyPeriod: editingProduct?.warrantyPeriod || '',
    warrantyUnit: editingProduct?.warrantyUnit || 'Months',
    isReturnable: editingProduct?.isReturnable !== false,
    returnDays: editingProduct?.returnDays ?? '7',
    isBulkManaged: !!editingProduct?.isBulkManaged,
    hasIndividualTracking: !!editingProduct?.hasIndividualTracking,
    bulkUnit: editingProduct?.bulkUnit || 'Bale',
    defaultBatchQuantity: editingProduct?.defaultBatchQuantity ?? editingProduct?.defaultQuantityPerBatch ?? '',
    videoUrl: editingProduct?.videoUrl || '',
  });

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [imageFiles, setImageFiles] = useState<File[]>([]);
  const [imagePreviews, setImagePreviews] = useState<string[]>([]);
  const [existingImages, setExistingImages] = useState<string[]>(
    () => editingProduct?.images || (editingProduct?.mainImage ? [editingProduct.mainImage] : [])
  );
  const imageInputRef = useRef<HTMLInputElement>(null);
  const [subCategories, setSubCategories] = useState<Category[]>([]);

  useEffect(() => {
    setExistingImages(editingProduct?.images || (editingProduct?.mainImage ? [editingProduct.mainImage] : []));
    setImageFiles([]);
  }, [editingProduct]);

  useEffect(() => {
    const urls = imageFiles.map((f) => URL.createObjectURL(f));
    setImagePreviews(urls);
    return () => urls.forEach((u) => URL.revokeObjectURL(u));
  }, [imageFiles]);

  const totalImageCount = existingImages.length + imageFiles.length;
  const remainingImageSlots = Math.max(0, 5 - totalImageCount);

  const handleAddImageFiles = (fileList: FileList | null) => {
    if (!fileList || remainingImageSlots <= 0) return;
    const incoming = Array.from(fileList).filter((f) => f.type.startsWith('image/'));
    if (!incoming.length) return;
    setImageFiles((prev) => {
      const slots = Math.max(0, 5 - existingImages.length - prev.length);
      return [...prev, ...incoming.slice(0, slots)];
    });
    if (imageInputRef.current) imageInputRef.current.value = '';
  };

  const productTypes = settingsData.productType || [];
  const stockUnits = settingsData.stockUnit || [];
  const weightUnits = settingsData.weightUnit || [];
  const dimensionUnits = settingsData.dimensionUnit || [];
  const sizes = settingsData.size || [];
  const shippingClasses = settingsData.shippingClass || [];
  const taxTypes = settingsData.taxType || [];
  const rackLocations = settingsData.rackLocation || [];
  const zones = settingsData.zone || [];
  const storageConditions = settingsData.storageCondition || [];

  const tabs = [
    { id: 'basic', label: 'Basic Info', icon: Info },
    { id: 'pricing', label: 'Pricing & Stock', icon: DollarSign },
    { id: 'category', label: 'Category & Supplier', icon: Building2 },
    { id: 'warehouse', label: 'Warehouse', icon: MapPin },
    { id: 'physical', label: 'Physical Attributes', icon: Ruler },
    { id: 'expiry', label: 'Expiry & Batch', icon: Clock },
    { id: 'shipping', label: 'Shipping', icon: Truck },
    { id: 'media', label: 'Media', icon: ImageIcon },
    { id: 'custom', label: 'Custom', icon: Layers },
  ];

  const handleInputChange = (field: string, value: any) => setFormData(prev => ({ ...prev, [field]: value }));

  const handleCategoryChange = async (categoryId: string) => {
    handleInputChange('category', categoryId);
    handleInputChange('subCategory', '');
    setSubCategories([]);

    if (!categoryId) return;

    // 1) Instant from flat list (parentId match)
    const fromFlat = (Array.isArray(categories) ? categories : [])
      .filter((c) => String(c.parentId || '') === String(categoryId))
      .map((c) => ({ ...c, id: c.id || (c as any)._id || '' }))
      .filter((c) => !!c.id);

    if (fromFlat.length > 0) {
      setSubCategories(fromFlat);
      return;
    }

    // 2) From nested children if tree was loaded
    const selectedCategory = categories.find(
      (c) => String(c.id || (c as any)._id) === String(categoryId)
    );
    const nested = (
      selectedCategory?.children ||
      selectedCategory?.subCategories ||
      []
    )
      .map((s) => ({ ...s, id: s.id || (s as any)._id || '' }))
      .filter((s) => !!s.id);

    if (nested.length > 0) {
      setSubCategories(nested);
      return;
    }

    // 3) API fetch by parentId
    setLoadingSubs(true);
    try {
      const subs = await categoryService.getSubCategories(categoryId);
      setSubCategories(subs);
    } catch (err) {
      console.error('Failed to load subcategories:', err);
      setSubCategories([]);
    } finally {
      setLoadingSubs(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    try {
      const payload = new FormData();
      
      const fieldMapping: Record<string, string> = {
        name: 'name',
        sku: 'sku',
        barcode: 'barcodeNumber',
        description: 'description',
        costPrice: 'costPrice',
        sellingPrice: 'sellingPrice',
        minimumStock: 'minimumStock',
        maximumStock: 'maximumStock',
        category: 'categoryId',
        supplier: 'supplierId',
        rackLocation: 'rackLocationName',
        productType: 'productType',
        stockUnit: 'stockUnitName',
        weightUnit: 'weightUnitName',
        dimensionUnit: 'dimensionUnitName',
        taxType: 'taxTypeName',
        zone: 'zoneName',
        storageCondition: 'storageConditionName',
        brand: 'brandName',
        modelNumber: 'modelNumber',
        currency: 'currencyCode',
        hsCode: 'hsCode',
        countryOfOrigin: 'countryOfOrigin',
        shippingClass: 'shippingClass',
        freightClass: 'freightClass',
        weight: 'weight',
        length: 'length',
        width: 'width',
        height: 'height',
        color: 'color',
        size: 'size',
        material: 'material',
        finish: 'finish',
        hasExpiry: 'hasExpiry',
        isBatchManaged: 'isBatchManaged',
        isSerialManaged: 'isSerialManaged',
        isExpiryManaged: 'isExpiryManaged',
        expiryDate: 'expiryDate',
        manufacturingDate: 'manufacturingDate',
        batchNumber: 'batchNumber',
        shelfLife: 'shelfLife',
        warrantyPeriod: 'warrantyPeriod',
        warrantyUnit: 'warrantyUnit',
        isReturnable: 'isReturnable',
        returnDays: 'returnDays',
        isBulkManaged: 'isBulkManaged',
        hasIndividualTracking: 'hasIndividualTracking',
        bulkUnit: 'bulkUnit',
        defaultBatchQuantity: 'defaultBatchQuantity',
        palletNumber: 'palletNumber',
        shelfNumber: 'shelfNumber',
        tempMin: 'tempMin',
        tempMax: 'tempMax',
        dangerousGoods: 'dangerousGoods',
        unNumber: 'unNumber',
        handlingInstructions: 'handlingInstructions',
        stackingLimit: 'stackingLimit',
        leadTime: 'leadTime',
        reorderPoint: 'reorderPoint',
        supplierSku: 'supplierSku',
        landingCost: 'landingCost',
        taxRate: 'taxRate'
      };

      Object.entries(fieldMapping).forEach(([frontField, backField]) => {
        if (frontField === 'category') return; // handled below with subcategory preference
        const value = formData[frontField as keyof typeof formData];
        if (value !== undefined && value !== null && value !== '') {
          if (typeof value === 'boolean') {
            payload.append(backField, String(value));
          } else {
            payload.append(backField, String(value));
          }
        }
      });

      const categoryId = formData.subCategory || formData.category;
      if (categoryId) payload.append('categoryId', String(categoryId));
      if (locationId && !isEditing) {
        payload.append('locationId', locationId);
      }

      if (formData.tags) {
        const tags = formData.tags.split(',').map(t => t.trim());
        payload.append('tags', JSON.stringify(tags));
      }

      payload.append('existingImages', JSON.stringify(existingImages));
      for (const file of imageFiles) {
        payload.append('images', file);
      }

      const editId = getProductId(editingProduct);
      if (isEditing && editId) {
        await productService.updateProduct(editId, payload);
      } else {
        await productService.createProduct(payload);
      }
      console.log('✅ [ProductForm] Product saved successfully');
      onSuccess();
    } catch (err: any) {
      console.error('❌ [ProductForm] Failed to save product:', err);
      setError(err.message || 'Failed to save product');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
      <div className="flex items-center justify-between px-4 md:px-6 py-3 md:py-4 border-b border-gray-100 bg-gray-50">
        <div className="flex items-center gap-2 md:gap-3">
          <Package className="w-4 h-4 md:w-5 md:h-5 text-[#014582]" />
          <h2 className="text-base md:text-lg font-bold text-gray-800">{isEditing ? 'Edit Product' : 'Create New Product'}</h2>
        </div>
        <div className="flex items-center gap-2 md:gap-3">
          <Link href="/warehouse/product-settings" className="flex items-center gap-1 md:gap-1.5 px-2 md:px-3 py-1 md:py-1.5 border border-gray-200 rounded-lg text-[10px] md:text-xs font-medium text-gray-600 hover:bg-gray-50 hover:border-[#014582] transition-all">
            <Settings className="w-3 h-3 md:w-3.5 md:h-3.5" /> Settings
          </Link>
          <button onClick={onCancel} className="p-1.5 md:p-2 hover:bg-gray-200 rounded-lg transition-all">
            <X className="w-4 h-4 md:w-5 md:h-5 text-gray-500" />
          </button>
        </div>
      </div>

      <div className="flex overflow-x-auto border-b border-gray-100 px-3 md:px-4 gap-0.5 md:gap-1">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button key={tab.id} onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-1.5 md:gap-2 px-2.5 md:px-4 py-2 md:py-3 text-[10px] md:text-sm font-medium border-b-2 transition-all whitespace-nowrap
                ${isActive ? 'border-[#014582] text-[#014582]' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'}`}>
              <Icon className={`w-3.5 h-3.5 md:w-4 md:h-4 ${isActive ? 'text-[#014582]' : 'text-gray-400'}`} />
              <span className="hidden xs:inline">{tab.label}</span>
            </button>
          );
        })}
      </div>

      <div className="p-3 md:p-6 max-h-[500px] md:max-h-[600px] overflow-y-auto">
        {error && <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-lg text-red-600 text-sm">{error}</div>}
        <form onSubmit={handleSubmit} className="space-y-4 md:space-y-6">

          {/* BASIC INFO */}
          {activeTab === 'basic' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 md:gap-4">
              <div>
                <label className="block text-xs md:text-sm font-semibold text-gray-700 mb-1.5">Product Name *</label>
                <div className="relative">
                  <Type className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 md:w-4 md:h-4 text-gray-400" />
                  <input type="text" placeholder="e.g., Cotton - Grade A" value={formData.name} onChange={(e) => handleInputChange('name', e.target.value)} className="w-full pl-8 md:pl-9 pr-3 md:pr-4 py-1.5 md:py-2.5 border border-gray-200 rounded-lg text-xs md:text-sm focus:ring-2 focus:ring-[#014582] focus:border-transparent outline-none bg-gray-50" required />
                </div>
              </div>
              <div>
                <label className="block text-xs md:text-sm font-semibold text-gray-700 mb-1.5">SKU *</label>
                <div className="relative">
                  <Hash className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 md:w-4 md:h-4 text-gray-400" />
                  <input type="text" placeholder="e.g., COT-001" value={formData.sku} onChange={(e) => handleInputChange('sku', e.target.value)} className="w-full pl-8 md:pl-9 pr-3 md:pr-4 py-1.5 md:py-2.5 border border-gray-200 rounded-lg text-xs md:text-sm focus:ring-2 focus:ring-[#014582] focus:border-transparent outline-none bg-gray-50" required />
                </div>
              </div>
              <div>
                <label className="block text-xs md:text-sm font-semibold text-gray-700 mb-1.5">Barcode</label>
                <div className="relative">
                  <Tag className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 md:w-4 md:h-4 text-gray-400" />
                  <input type="text" placeholder="Enter barcode or leave blank to use SKU" value={formData.barcode} onChange={(e) => handleInputChange('barcode', e.target.value)} className="w-full pl-8 md:pl-9 pr-3 md:pr-4 py-1.5 md:py-2.5 border border-gray-200 rounded-lg text-xs md:text-sm focus:ring-2 focus:ring-[#014582] focus:border-transparent outline-none bg-gray-50" />
                </div>
                <p className="text-[10px] md:text-xs text-gray-400 mt-1">Leave blank — SKU will be used as barcode automatically</p>
              </div>
              <div>
                <label className="block text-xs md:text-sm font-semibold text-gray-700 mb-1.5">Product Type</label>
                <QuickAddSelect
                  kind="setting"
                  settingCategory="productType"
                  title="Add product type"
                  value={formData.productType}
                  onChange={(v) => handleInputChange('productType', v)}
                  placeholder="Select type..."
                  options={productTypes.map((type) => ({
                    value: type.name,
                    label: type.name,
                  }))}
                  onCreated={(opt, raw) => {
                    onSettingCreated?.('productType', raw || { name: opt.label });
                  }}
                />
              </div>
              <div className="col-span-2">
                <label className="block text-xs md:text-sm font-semibold text-gray-700 mb-1.5">Description</label>
                <div className="relative">
                  <AlignLeft className="absolute left-3 top-2.5 md:top-3 w-3.5 h-3.5 md:w-4 md:h-4 text-gray-400" />
                  <textarea placeholder="Enter product description..." rows={3} value={formData.description} onChange={(e) => handleInputChange('description', e.target.value)} className="w-full pl-8 md:pl-9 pr-3 md:pr-4 py-1.5 md:py-2.5 border border-gray-200 rounded-lg text-xs md:text-sm focus:ring-2 focus:ring-[#014582] focus:border-transparent outline-none bg-gray-50 resize-none" />
                </div>
              </div>
              <div className="col-span-2">
                <label className="block text-xs md:text-sm font-semibold text-gray-700 mb-1.5">Tags</label>
                <input type="text" placeholder="e.g., cotton, grade-a, raw-material" value={formData.tags} onChange={(e) => handleInputChange('tags', e.target.value)} className="w-full px-3 md:px-4 py-1.5 md:py-2.5 border border-gray-200 rounded-lg text-xs md:text-sm focus:ring-2 focus:ring-[#014582] focus:border-transparent outline-none bg-gray-50" />
              </div>
            </div>
          )}

          {/* PRICING & STOCK */}
          {activeTab === 'pricing' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 md:gap-4">
              <div>
                <label className="block text-xs md:text-sm font-semibold text-gray-700 mb-1.5">Cost Price *</label>
                <div className="relative">
                  <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 md:w-4 md:h-4 text-gray-400" />
                  <input type="number" step="0.01" placeholder="0.00" value={formData.costPrice} onChange={(e) => handleInputChange('costPrice', e.target.value)} className="w-full pl-8 md:pl-9 pr-3 md:pr-4 py-1.5 md:py-2.5 border border-gray-200 rounded-lg text-xs md:text-sm focus:ring-2 focus:ring-[#014582] focus:border-transparent outline-none bg-gray-50" required />
                </div>
              </div>
              <div>
                <label className="block text-xs md:text-sm font-semibold text-gray-700 mb-1.5">Selling Price *</label>
                <div className="relative">
                  <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 md:w-4 md:h-4 text-gray-400" />
                  <input type="number" step="0.01" placeholder="0.00" value={formData.sellingPrice} onChange={(e) => handleInputChange('sellingPrice', e.target.value)} className="w-full pl-8 md:pl-9 pr-3 md:pr-4 py-1.5 md:py-2.5 border border-gray-200 rounded-lg text-xs md:text-sm focus:ring-2 focus:ring-[#014582] focus:border-transparent outline-none bg-gray-50" required />
                </div>
              </div>
              <div>
                <label className="block text-xs md:text-sm font-semibold text-gray-700 mb-1.5">Landing Cost</label>
                <div className="relative">
                  <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 md:w-4 md:h-4 text-gray-400" />
                  <input type="number" step="0.01" placeholder="0.00" value={formData.landingCost} onChange={(e) => handleInputChange('landingCost', e.target.value)} className="w-full pl-8 md:pl-9 pr-3 md:pr-4 py-1.5 md:py-2.5 border border-gray-200 rounded-lg text-xs md:text-sm focus:ring-2 focus:ring-[#014582] focus:border-transparent outline-none bg-gray-50" />
                </div>
              </div>
              <div>
                <label className="block text-xs md:text-sm font-semibold text-gray-700 mb-1.5">Currency *</label>
                <QuickAddSelect
                  kind="local"
                  title="Add currency"
                  value={formData.currency}
                  onChange={(v) => handleInputChange('currency', v)}
                  placeholder="Select currency..."
                  required
                  options={[
                    ...['PKR', 'USD', 'EUR', 'GBP', 'AUD']
                      .concat(
                        formData.currency &&
                          !['PKR', 'USD', 'EUR', 'GBP', 'AUD'].includes(formData.currency)
                          ? [formData.currency]
                          : []
                      )
                      .filter((v, i, arr) => arr.indexOf(v) === i)
                      .map((c) => ({ value: c, label: c })),
                  ]}
                />
              </div>
              <div className="md:col-span-2">
                <ProductTaxFields
                  taxRate={formData.taxRate}
                  taxType={formData.taxType}
                  onChange={({ taxRate, taxType }) => {
                    handleInputChange('taxRate', taxRate);
                    handleInputChange('taxType', taxType);
                  }}
                />
              </div>
              <div>
                <label className="block text-xs md:text-sm font-semibold text-gray-700 mb-1.5">Stock Unit</label>
                <QuickAddSelect
                  kind="setting"
                  settingCategory="stockUnit"
                  title="Add stock unit"
                  value={formData.stockUnit}
                  onChange={(v) => handleInputChange('stockUnit', v)}
                  placeholder="Select unit..."
                  options={stockUnits.map((unit) => ({
                    value: unit.name,
                    label: unit.name,
                  }))}
                  onCreated={(opt, raw) => {
                    onSettingCreated?.('stockUnit', raw || { name: opt.label });
                  }}
                />
              </div>
              <div>
                <label className="block text-xs md:text-sm font-semibold text-gray-700 mb-1.5">
                  {editingProduct ? 'Current Stock (read-only)' : 'Opening Stock'}
                </label>
                <div className="relative">
                  <Box className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 md:w-4 md:h-4 text-gray-400" />
                  <input
                    type="number"
                    value={editingProduct ? (editingProduct.currentStock ?? 0) : 0}
                    readOnly
                    disabled
                    className="w-full pl-8 md:pl-9 pr-3 md:pr-4 py-1.5 md:py-2.5 border border-gray-200 rounded-lg text-xs md:text-sm bg-gray-100 text-gray-600 cursor-not-allowed"
                  />
                </div>
                {!editingProduct && (
                  <p className="text-[10px] md:text-xs text-blue-700 mt-1">
                    Add opening stock via{' '}
                    <Link href="/warehouse/stock-movement" className="underline font-semibold">
                      Stock Movement → Opening Stock
                    </Link>{' '}
                    (posts accounting entry).
                  </p>
                )}
              </div>
              <div>
                <label className="block text-xs md:text-sm font-semibold text-gray-700 mb-1.5">Minimum Stock</label>
                <input type="number" placeholder="5" value={formData.minimumStock} onChange={(e) => handleInputChange('minimumStock', e.target.value)} className="w-full px-3 md:px-4 py-1.5 md:py-2.5 border border-gray-200 rounded-lg text-xs md:text-sm focus:ring-2 focus:ring-[#014582] focus:border-transparent outline-none bg-gray-50" />
              </div>
              <div>
                <label className="block text-xs md:text-sm font-semibold text-gray-700 mb-1.5">Maximum Stock</label>
                <input type="number" placeholder="100" value={formData.maximumStock} onChange={(e) => handleInputChange('maximumStock', e.target.value)} className="w-full px-3 md:px-4 py-1.5 md:py-2.5 border border-gray-200 rounded-lg text-xs md:text-sm focus:ring-2 focus:ring-[#014582] focus:border-transparent outline-none bg-gray-50" />
              </div>
            </div>
          )}

          {/* CATEGORY & SUPPLIER */}
          {activeTab === 'category' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 md:gap-4">
              <div>
                <label className="block text-xs md:text-sm font-semibold text-gray-700 mb-1.5">Category *</label>
                <QuickAddSelect
                  kind="category"
                  title="Add category"
                  value={formData.category}
                  onChange={(v) => handleCategoryChange(v)}
                  placeholder="Select category..."
                  required
                  options={categoryList.map((cat) => ({
                    value: String(cat.id || ''),
                    label: cat.name,
                  }))}
                  onCreated={(opt, raw) => {
                    const cat = {
                      ...(raw as Category),
                      id: opt.value,
                      name: opt.label,
                      parentId: null,
                    };
                    onCategoryCreated?.(cat);
                  }}
                />
              </div>
              
              <div>
                <label className="block text-xs md:text-sm font-semibold text-gray-700 mb-1.5">Sub-Category</label>
                <QuickAddSelect
                  kind="subcategory"
                  title="Add sub-category"
                  parentCategoryId={formData.category || undefined}
                  value={formData.subCategory}
                  onChange={(v) => handleInputChange('subCategory', v)}
                  placeholder={
                    loadingSubs
                      ? 'Loading sub-categories...'
                      : !formData.category
                        ? 'Select category first'
                        : subCategories.length === 0
                          ? 'No sub-categories — click + to add'
                          : 'Select sub-category...'
                  }
                  disabled={loadingSubs || !formData.category}
                  options={subCategories.map((sub) => ({
                    value: String(sub.id || ''),
                    label: sub.name,
                  }))}
                  onCreated={(opt, raw) => {
                    const cat = {
                      ...(raw as Category),
                      id: opt.value,
                      name: opt.label,
                      parentId: formData.category,
                    };
                    setSubCategories((prev) => [...prev, cat]);
                    onCategoryCreated?.(cat);
                  }}
                />
              </div>
              
              <div>
                <label className="block text-xs md:text-sm font-semibold text-gray-700 mb-1.5">Brand</label>
                <input 
                  type="text" 
                  placeholder="Brand name" 
                  value={formData.brand} 
                  onChange={(e) => handleInputChange('brand', e.target.value)} 
                  className="w-full px-3 md:px-4 py-1.5 md:py-2.5 border border-gray-200 rounded-lg text-xs md:text-sm focus:ring-2 focus:ring-[#014582] focus:border-transparent outline-none bg-gray-50" 
                />
              </div>
              
              <div>
                <label className="block text-xs md:text-sm font-semibold text-gray-700 mb-1.5">Model Number</label>
                <input 
                  type="text" 
                  placeholder="Model #" 
                  value={formData.modelNumber} 
                  onChange={(e) => handleInputChange('modelNumber', e.target.value)} 
                  className="w-full px-3 md:px-4 py-1.5 md:py-2.5 border border-gray-200 rounded-lg text-xs md:text-sm focus:ring-2 focus:ring-[#014582] focus:border-transparent outline-none bg-gray-50" 
                />
              </div>
              
              <div>
                <label className="block text-xs md:text-sm font-semibold text-gray-700 mb-1.5">Supplier *</label>
                <QuickAddSelect
                  kind="supplier"
                  title="Add supplier"
                  value={formData.supplier}
                  onChange={(v) => handleInputChange('supplier', v)}
                  placeholder="Select supplier..."
                  required
                  options={supplierList.map((sup) => {
                    const id = String((sup as any).id || (sup as any)._id || '');
                    return { value: id, label: sup.name };
                  }).filter((o) => !!o.value)}
                  onCreated={(opt, raw) => {
                    const data = (raw as any)?.data || raw;
                    onSupplierCreated?.({
                      ...(data as Supplier),
                      id: opt.value,
                      name: opt.label,
                    } as Supplier);
                  }}
                />
              </div>
              
              <div>
                <label className="block text-xs md:text-sm font-semibold text-gray-700 mb-1.5">Supplier SKU</label>
                <input 
                  type="text" 
                  placeholder="Supplier SKU" 
                  value={formData.supplierSku} 
                  onChange={(e) => handleInputChange('supplierSku', e.target.value)} 
                  className="w-full px-3 md:px-4 py-1.5 md:py-2.5 border border-gray-200 rounded-lg text-xs md:text-sm focus:ring-2 focus:ring-[#014582] focus:border-transparent outline-none bg-gray-50" 
                />
              </div>
              
              <div>
                <label className="block text-xs md:text-sm font-semibold text-gray-700 mb-1.5">Lead Time (Days)</label>
                <input 
                  type="number" 
                  placeholder="7" 
                  value={formData.leadTime} 
                  onChange={(e) => handleInputChange('leadTime', e.target.value)} 
                  className="w-full px-3 md:px-4 py-1.5 md:py-2.5 border border-gray-200 rounded-lg text-xs md:text-sm focus:ring-2 focus:ring-[#014582] focus:border-transparent outline-none bg-gray-50" 
                />
              </div>
              
              <div>
                <label className="block text-xs md:text-sm font-semibold text-gray-700 mb-1.5">Reorder Point</label>
                <input 
                  type="number" 
                  placeholder="100" 
                  value={formData.reorderPoint} 
                  onChange={(e) => handleInputChange('reorderPoint', e.target.value)} 
                  className="w-full px-3 md:px-4 py-1.5 md:py-2.5 border border-gray-200 rounded-lg text-xs md:text-sm focus:ring-2 focus:ring-[#014582] focus:border-transparent outline-none bg-gray-50" 
                />
              </div>
            </div>
          )}

          {/* WAREHOUSE */}
          {activeTab === 'warehouse' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 md:gap-4">
              <div>
                <label className="block text-xs md:text-sm font-semibold text-gray-700 mb-1.5">Rack Location</label>
                <QuickAddSelect
                  kind="setting"
                  settingCategory="rackLocation"
                  title="Add rack location"
                  value={formData.rackLocation}
                  onChange={(v) => handleInputChange('rackLocation', v)}
                  placeholder="Select rack..."
                  options={rackLocations.map((rack) => ({
                    value: rack.name,
                    label: rack.name,
                  }))}
                  onCreated={(opt, raw) => {
                    onSettingCreated?.('rackLocation', raw || { name: opt.label });
                  }}
                />
              </div>
              <div>
                <label className="block text-xs md:text-sm font-semibold text-gray-700 mb-1.5">Zone</label>
                <QuickAddSelect
                  kind="setting"
                  settingCategory="zone"
                  title="Add zone"
                  value={formData.zone}
                  onChange={(v) => handleInputChange('zone', v)}
                  placeholder="Select zone..."
                  options={zones.map((zone) => ({
                    value: zone.name,
                    label: zone.name,
                  }))}
                  onCreated={(opt, raw) => {
                    onSettingCreated?.('zone', raw || { name: opt.label });
                  }}
                />
              </div>
              <div>
                <label className="block text-xs md:text-sm font-semibold text-gray-700 mb-1.5">Pallet Number</label>
                <input type="text" placeholder="Pallet #" value={formData.palletNumber} onChange={(e) => handleInputChange('palletNumber', e.target.value)} className="w-full px-3 md:px-4 py-1.5 md:py-2.5 border border-gray-200 rounded-lg text-xs md:text-sm focus:ring-2 focus:ring-[#014582] focus:border-transparent outline-none bg-gray-50" />
              </div>
              <div>
                <label className="block text-xs md:text-sm font-semibold text-gray-700 mb-1.5">Shelf Number</label>
                <input type="text" placeholder="Shelf #" value={formData.shelfNumber} onChange={(e) => handleInputChange('shelfNumber', e.target.value)} className="w-full px-3 md:px-4 py-1.5 md:py-2.5 border border-gray-200 rounded-lg text-xs md:text-sm focus:ring-2 focus:ring-[#014582] focus:border-transparent outline-none bg-gray-50" />
              </div>
              <div>
                <label className="block text-xs md:text-sm font-semibold text-gray-700 mb-1.5">Storage Condition</label>
                <QuickAddSelect
                  kind="setting"
                  settingCategory="storageCondition"
                  title="Add storage condition"
                  value={formData.storageCondition}
                  onChange={(v) => handleInputChange('storageCondition', v)}
                  placeholder="Select condition..."
                  options={storageConditions.map((cond) => ({
                    value: cond.name,
                    label: cond.name,
                  }))}
                  onCreated={(opt, raw) => {
                    onSettingCreated?.('storageCondition', raw || { name: opt.label });
                  }}
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs md:text-sm font-semibold text-gray-700 mb-1.5">Temp Min (°C)</label>
                  <input type="number" placeholder="0" value={formData.tempMin} onChange={(e) => handleInputChange('tempMin', e.target.value)} className="w-full px-3 md:px-4 py-1.5 md:py-2.5 border border-gray-200 rounded-lg text-xs md:text-sm focus:ring-2 focus:ring-[#014582] focus:border-transparent outline-none bg-gray-50" />
                </div>
                <div>
                  <label className="block text-xs md:text-sm font-semibold text-gray-700 mb-1.5">Temp Max (°C)</label>
                  <input type="number" placeholder="40" value={formData.tempMax} onChange={(e) => handleInputChange('tempMax', e.target.value)} className="w-full px-3 md:px-4 py-1.5 md:py-2.5 border border-gray-200 rounded-lg text-xs md:text-sm focus:ring-2 focus:ring-[#014582] focus:border-transparent outline-none bg-gray-50" />
                </div>
              </div>
            </div>
          )}

          {/* PHYSICAL ATTRIBUTES */}
          {activeTab === 'physical' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 md:gap-4">
              <div>
                <label className="block text-xs md:text-sm font-semibold text-gray-700 mb-1.5">Weight</label>
                <div className="flex gap-2 items-start">
                  <div className="relative flex-1">
                    <Scale className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 md:w-4 md:h-4 text-gray-400" />
                    <input type="number" step="0.01" placeholder="0.00" value={formData.weight} onChange={(e) => handleInputChange('weight', e.target.value)} className="w-full pl-8 md:pl-9 pr-3 md:pr-4 py-1.5 md:py-2.5 border border-gray-200 rounded-lg text-xs md:text-sm focus:ring-2 focus:ring-[#014582] focus:border-transparent outline-none bg-gray-50" />
                  </div>
                  <div className="w-36 md:w-40 flex-shrink-0">
                    <QuickAddSelect
                      kind="setting"
                      settingCategory="weightUnit"
                      title="Add weight unit"
                      value={formData.weightUnit}
                      onChange={(v) => handleInputChange('weightUnit', v)}
                      placeholder="Unit"
                      options={weightUnits.map((unit) => ({
                        value: unit.name,
                        label: unit.name,
                      }))}
                      onCreated={(opt, raw) => {
                        onSettingCreated?.('weightUnit', raw || { name: opt.label });
                      }}
                    />
                  </div>
                </div>
              </div>
              <div>
                <label className="block text-xs md:text-sm font-semibold text-gray-700 mb-1.5">Dimension Unit</label>
                <QuickAddSelect
                  kind="setting"
                  settingCategory="dimensionUnit"
                  title="Add dimension unit"
                  value={formData.dimensionUnit}
                  onChange={(v) => handleInputChange('dimensionUnit', v)}
                  placeholder="Select unit..."
                  options={dimensionUnits.map((unit) => ({
                    value: unit.name,
                    label: unit.name,
                  }))}
                  onCreated={(opt, raw) => {
                    onSettingCreated?.('dimensionUnit', raw || { name: opt.label });
                  }}
                />
              </div>
              <div>
                <label className="block text-xs md:text-sm font-semibold text-gray-700 mb-1.5">Length</label>
                <div className="relative">
                  <Ruler className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 md:w-4 md:h-4 text-gray-400" />
                  <input type="number" placeholder="0" value={formData.length} onChange={(e) => handleInputChange('length', e.target.value)} className="w-full pl-8 md:pl-9 pr-3 md:pr-4 py-1.5 md:py-2.5 border border-gray-200 rounded-lg text-xs md:text-sm focus:ring-2 focus:ring-[#014582] focus:border-transparent outline-none bg-gray-50" />
                </div>
              </div>
              <div>
                <label className="block text-xs md:text-sm font-semibold text-gray-700 mb-1.5">Width</label>
                <input type="number" placeholder="0" value={formData.width} onChange={(e) => handleInputChange('width', e.target.value)} className="w-full px-3 md:px-4 py-1.5 md:py-2.5 border border-gray-200 rounded-lg text-xs md:text-sm focus:ring-2 focus:ring-[#014582] focus:border-transparent outline-none bg-gray-50" />
              </div>
              <div>
                <label className="block text-xs md:text-sm font-semibold text-gray-700 mb-1.5">Height</label>
                <input type="number" placeholder="0" value={formData.height} onChange={(e) => handleInputChange('height', e.target.value)} className="w-full px-3 md:px-4 py-1.5 md:py-2.5 border border-gray-200 rounded-lg text-xs md:text-sm focus:ring-2 focus:ring-[#014582] focus:border-transparent outline-none bg-gray-50" />
              </div>
              <div>
                <label className="block text-xs md:text-sm font-semibold text-gray-700 mb-1.5">Color</label>
                <input type="text" placeholder="e.g., White" value={formData.color} onChange={(e) => handleInputChange('color', e.target.value)} className="w-full px-3 md:px-4 py-1.5 md:py-2.5 border border-gray-200 rounded-lg text-xs md:text-sm focus:ring-2 focus:ring-[#014582] focus:border-transparent outline-none bg-gray-50" />
              </div>
              <div>
                <label className="block text-xs md:text-sm font-semibold text-gray-700 mb-1.5">Size</label>
                <QuickAddSelect
                  kind="setting"
                  settingCategory="size"
                  title="Add size"
                  value={formData.size}
                  onChange={(v) => handleInputChange('size', v)}
                  placeholder="Select size..."
                  options={sizes.map((size) => ({
                    value: size.name,
                    label: size.name,
                  }))}
                  onCreated={(opt, raw) => {
                    onSettingCreated?.('size', raw || { name: opt.label });
                  }}
                />
              </div>
              <div>
                <label className="block text-xs md:text-sm font-semibold text-gray-700 mb-1.5">Material</label>
                <input type="text" placeholder="e.g., 100% Cotton" value={formData.material} onChange={(e) => handleInputChange('material', e.target.value)} className="w-full px-3 md:px-4 py-1.5 md:py-2.5 border border-gray-200 rounded-lg text-xs md:text-sm focus:ring-2 focus:ring-[#014582] focus:border-transparent outline-none bg-gray-50" />
              </div>
              <div>
                <label className="block text-xs md:text-sm font-semibold text-gray-700 mb-1.5">Finish</label>
                <input type="text" placeholder="e.g., Matte, Glossy" value={formData.finish} onChange={(e) => handleInputChange('finish', e.target.value)} className="w-full px-3 md:px-4 py-1.5 md:py-2.5 border border-gray-200 rounded-lg text-xs md:text-sm focus:ring-2 focus:ring-[#014582] focus:border-transparent outline-none bg-gray-50" />
              </div>
            </div>
          )}

          {/* EXPIRY & BATCH */}
          {activeTab === 'expiry' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 md:gap-4">
              {[
                { key: 'hasExpiry', label: 'Has Expiry' },
                { key: 'isBatchManaged', label: 'Batch Managed' },
                { key: 'isSerialManaged', label: 'Serial Managed' },
                { key: 'isExpiryManaged', label: 'Expiry Managed' },
              ].map(({ key, label }) => (
                <div key={key} className="flex items-center gap-3">
                  <input type="checkbox" checked={formData[key as keyof typeof formData] as boolean} onChange={(e) => handleInputChange(key, e.target.checked)} className="w-4 h-4 text-[#014582] rounded border-gray-300" />
                  <label className="text-xs md:text-sm font-medium text-gray-700">{label}</label>
                </div>
              ))}
              <div>
                <label className="block text-xs md:text-sm font-semibold text-gray-700 mb-1.5">Expiry Date</label>
                <div className="relative">
                  <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 md:w-4 md:h-4 text-gray-400" />
                  <input type="date" value={formData.expiryDate} onChange={(e) => handleInputChange('expiryDate', e.target.value)} className="w-full pl-8 md:pl-9 pr-3 md:pr-4 py-1.5 md:py-2.5 border border-gray-200 rounded-lg text-xs md:text-sm focus:ring-2 focus:ring-[#014582] focus:border-transparent outline-none bg-gray-50" />
                </div>
              </div>
              <div>
                <label className="block text-xs md:text-sm font-semibold text-gray-700 mb-1.5">Manufacturing Date</label>
                <div className="relative">
                  <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 md:w-4 md:h-4 text-gray-400" />
                  <input type="date" value={formData.manufacturingDate} onChange={(e) => handleInputChange('manufacturingDate', e.target.value)} className="w-full pl-8 md:pl-9 pr-3 md:pr-4 py-1.5 md:py-2.5 border border-gray-200 rounded-lg text-xs md:text-sm focus:ring-2 focus:ring-[#014582] focus:border-transparent outline-none bg-gray-50" />
                </div>
              </div>
              <div>
                <label className="block text-xs md:text-sm font-semibold text-gray-700 mb-1.5">Batch Number</label>
                <input type="text" placeholder="BATCH-001" value={formData.batchNumber} onChange={(e) => handleInputChange('batchNumber', e.target.value)} className="w-full px-3 md:px-4 py-1.5 md:py-2.5 border border-gray-200 rounded-lg text-xs md:text-sm focus:ring-2 focus:ring-[#014582] focus:border-transparent outline-none bg-gray-50" />
              </div>
              <div>
                <label className="block text-xs md:text-sm font-semibold text-gray-700 mb-1.5">Shelf Life (Days)</label>
                <input type="number" placeholder="365" value={formData.shelfLife} onChange={(e) => handleInputChange('shelfLife', e.target.value)} className="w-full px-3 md:px-4 py-1.5 md:py-2.5 border border-gray-200 rounded-lg text-xs md:text-sm focus:ring-2 focus:ring-[#014582] focus:border-transparent outline-none bg-gray-50" />
              </div>
              <div className="col-span-2 border-t border-gray-100 pt-3 md:pt-4 mt-2">
                <h4 className="text-xs md:text-sm font-semibold text-gray-700 mb-2 md:mb-3">Bulk Management (Cotton/Fabric)</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 md:gap-4">
                  <div className="flex items-center gap-3">
                    <input type="checkbox" checked={formData.isBulkManaged} onChange={(e) => handleInputChange('isBulkManaged', e.target.checked)} className="w-4 h-4 text-[#014582] rounded border-gray-300" />
                    <label className="text-xs md:text-sm font-medium text-gray-700">Bulk Managed</label>
                  </div>
                  <div className="flex items-center gap-3">
                    <input type="checkbox" checked={formData.hasIndividualTracking} onChange={(e) => handleInputChange('hasIndividualTracking', e.target.checked)} className="w-4 h-4 text-[#014582] rounded border-gray-300" />
                    <label className="text-xs md:text-sm font-medium text-gray-700">Individual Tracking</label>
                  </div>
                  <div>
                    <label className="block text-xs md:text-sm font-semibold text-gray-700 mb-1.5">Bulk Unit</label>
                    <select value={formData.bulkUnit} onChange={(e) => handleInputChange('bulkUnit', e.target.value)} className="w-full px-3 md:px-4 py-1.5 md:py-2.5 border border-gray-200 rounded-lg text-xs md:text-sm focus:ring-2 focus:ring-[#014582] focus:border-transparent outline-none bg-gray-50">
                      <option>Bale</option><option>Box</option><option>Roll</option><option>Pallet</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs md:text-sm font-semibold text-gray-700 mb-1.5">Default Batch Quantity</label>
                    <input type="number" placeholder="50" value={formData.defaultBatchQuantity} onChange={(e) => handleInputChange('defaultBatchQuantity', e.target.value)} className="w-full px-3 md:px-4 py-1.5 md:py-2.5 border border-gray-200 rounded-lg text-xs md:text-sm focus:ring-2 focus:ring-[#014582] focus:border-transparent outline-none bg-gray-50" />
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* SHIPPING */}
          {activeTab === 'shipping' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 md:gap-4">
              <div>
                <label className="block text-xs md:text-sm font-semibold text-gray-700 mb-1.5">HS Code</label>
                <input type="text" placeholder="e.g., 5201.00.00" value={formData.hsCode} onChange={(e) => handleInputChange('hsCode', e.target.value)} className="w-full px-3 md:px-4 py-1.5 md:py-2.5 border border-gray-200 rounded-lg text-xs md:text-sm focus:ring-2 focus:ring-[#014582] focus:border-transparent outline-none bg-gray-50" />
              </div>
              <div>
                <label className="block text-xs md:text-sm font-semibold text-gray-700 mb-1.5">Country of Origin</label>
                <select value={formData.countryOfOrigin} onChange={(e) => handleInputChange('countryOfOrigin', e.target.value)} className="w-full px-3 md:px-4 py-1.5 md:py-2.5 border border-gray-200 rounded-lg text-xs md:text-sm focus:ring-2 focus:ring-[#014582] focus:border-transparent outline-none bg-gray-50">
                  <option>Pakistan</option><option>China</option><option>USA</option><option>Turkey</option><option>India</option>
                </select>
              </div>
              <div>
                <label className="block text-xs md:text-sm font-semibold text-gray-700 mb-1.5">Shipping Class</label>
                <QuickAddSelect
                  kind="setting"
                  settingCategory="shippingClass"
                  title="Add shipping class"
                  value={formData.shippingClass}
                  onChange={(v) => handleInputChange('shippingClass', v)}
                  placeholder="Select class..."
                  options={shippingClasses.map((cls) => ({
                    value: cls.name,
                    label: cls.name,
                  }))}
                  onCreated={(opt, raw) => {
                    onSettingCreated?.('shippingClass', raw || { name: opt.label });
                  }}
                />
              </div>
              <div>
                <label className="block text-xs md:text-sm font-semibold text-gray-700 mb-1.5">Freight Class</label>
                <input type="text" placeholder="Freight class" value={formData.freightClass} onChange={(e) => handleInputChange('freightClass', e.target.value)} className="w-full px-3 md:px-4 py-1.5 md:py-2.5 border border-gray-200 rounded-lg text-xs md:text-sm focus:ring-2 focus:ring-[#014582] focus:border-transparent outline-none bg-gray-50" />
              </div>
              <div>
                <label className="block text-xs md:text-sm font-semibold text-gray-700 mb-1.5">Stacking Limit</label>
                <input type="number" placeholder="5" value={formData.stackingLimit} onChange={(e) => handleInputChange('stackingLimit', e.target.value)} className="w-full px-3 md:px-4 py-1.5 md:py-2.5 border border-gray-200 rounded-lg text-xs md:text-sm focus:ring-2 focus:ring-[#014582] focus:border-transparent outline-none bg-gray-50" />
              </div>
              <div className="flex items-center gap-3 mt-1 md:mt-2">
                <input type="checkbox" checked={formData.dangerousGoods} onChange={(e) => handleInputChange('dangerousGoods', e.target.checked)} className="w-4 h-4 text-[#014582] rounded border-gray-300" />
                <label className="text-xs md:text-sm font-medium text-gray-700">Dangerous Goods</label>
              </div>
              <div>
                <label className="block text-xs md:text-sm font-semibold text-gray-700 mb-1.5">UN Number</label>
                <input type="text" placeholder="UN #" value={formData.unNumber} onChange={(e) => handleInputChange('unNumber', e.target.value)} className="w-full px-3 md:px-4 py-1.5 md:py-2.5 border border-gray-200 rounded-lg text-xs md:text-sm focus:ring-2 focus:ring-[#014582] focus:border-transparent outline-none bg-gray-50" />
              </div>
              <div className="col-span-2">
                <label className="block text-xs md:text-sm font-semibold text-gray-700 mb-1.5">Handling Instructions</label>
                <input type="text" placeholder="Special handling instructions..." value={formData.handlingInstructions} onChange={(e) => handleInputChange('handlingInstructions', e.target.value)} className="w-full px-3 md:px-4 py-1.5 md:py-2.5 border border-gray-200 rounded-lg text-xs md:text-sm focus:ring-2 focus:ring-[#014582] focus:border-transparent outline-none bg-gray-50" />
              </div>
            </div>
          )}

          {/* MEDIA */}
          {activeTab === 'media' && (
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="block text-xs md:text-sm font-semibold text-gray-700">Product Images</label>
                <span className="text-[10px] md:text-xs font-medium text-gray-500">{totalImageCount} / 5</span>
              </div>
              <p className="text-[10px] md:text-xs text-gray-400 mb-3">
                Select multiple images (Ctrl/Cmd). First image is main. You can add more in batches.
              </p>
              <div className="flex flex-wrap gap-2 md:gap-3 mb-3">
                {existingImages.map((url, idx) => (
                  <div key={`existing-${url}`} className="relative w-20 h-20 md:w-24 md:h-24 rounded-xl overflow-hidden border border-gray-200 bg-gray-50">
                    <img src={url} alt={`Product ${idx + 1}`} className="w-full h-full object-cover" />
                    {idx === 0 && imageFiles.length === 0 && (
                      <span className="absolute bottom-1 left-1 text-[9px] font-bold bg-[#014582] text-white px-1.5 py-0.5 rounded">Main</span>
                    )}
                    <button type="button" onClick={() => setExistingImages((prev) => prev.filter((u) => u !== url))} className="absolute top-0.5 right-0.5 p-0.5 bg-red-500 text-white rounded">
                      <X className="w-3 h-3" />
                    </button>
                  </div>
                ))}
                {imagePreviews.map((url, idx) => (
                  <div key={`new-${url}`} className="relative w-20 h-20 md:w-24 md:h-24 rounded-xl overflow-hidden border-2 border-[#014582]/40 bg-gray-50">
                    <img src={url} alt={`New ${idx + 1}`} className="w-full h-full object-cover" />
                    {existingImages.length === 0 && idx === 0 && (
                      <span className="absolute bottom-1 left-1 text-[9px] font-bold bg-[#014582] text-white px-1.5 py-0.5 rounded">Main</span>
                    )}
                    <button type="button" onClick={() => setImageFiles((prev) => prev.filter((_, i) => i !== idx))} className="absolute top-0.5 right-0.5 p-0.5 bg-red-500 text-white rounded">
                      <X className="w-3 h-3" />
                    </button>
                  </div>
                ))}
                {remainingImageSlots > 0 && (
                  <button
                    type="button"
                    onClick={() => imageInputRef.current?.click()}
                    className="w-20 h-20 md:w-24 md:h-24 rounded-xl border-2 border-dashed border-gray-300 hover:border-[#014582] hover:bg-[#014582]/5 transition-all flex flex-col items-center justify-center gap-1 text-gray-400 hover:text-[#014582]"
                  >
                    <ImageIcon className="w-5 h-5 md:w-6 md:h-6" />
                    <span className="text-[9px] md:text-[10px] font-semibold">Add images</span>
                    <span className="text-[9px]">{remainingImageSlots} left</span>
                  </button>
                )}
              </div>
              <input
                ref={imageInputRef}
                type="file"
                multiple
                accept="image/png,image/jpeg,image/jpg,image/webp"
                className="hidden"
                onChange={(e) => handleAddImageFiles(e.target.files)}
              />
              {remainingImageSlots > 0 && (
                <button
                  type="button"
                  onClick={() => imageInputRef.current?.click()}
                  className="inline-flex items-center gap-2 px-3 md:px-4 py-1.5 md:py-2 border border-gray-200 rounded-lg text-xs md:text-sm font-medium text-gray-700 hover:border-[#014582] hover:text-[#014582] transition-all"
                >
                  <Upload className="w-3.5 h-3.5 md:w-4 md:h-4" />
                  Choose multiple images
                </button>
              )}
            </div>
          )}

          {/* CUSTOM */}
          {activeTab === 'custom' && (
            <div className="space-y-3 md:space-y-4">
              <div className="bg-gray-50 rounded-lg p-3 md:p-4 border border-gray-200">
                <div className="flex items-center justify-between mb-2 md:mb-3">
                  <h4 className="text-xs md:text-sm font-semibold text-gray-700">Custom Attributes</h4>
                  <button type="button" className="text-xs md:text-sm text-[#014582] font-semibold hover:text-[#01366a]">+ Add Field</button>
                </div>
                <div className="grid grid-cols-2 gap-2 md:gap-3">
                  <input type="text" placeholder="Attribute Name" className="px-2 md:px-3 py-1.5 md:py-2 border border-gray-200 rounded-lg text-xs md:text-sm focus:ring-2 focus:ring-[#014582] focus:border-transparent outline-none bg-white" />
                  <input type="text" placeholder="Value" className="px-2 md:px-3 py-1.5 md:py-2 border border-gray-200 rounded-lg text-xs md:text-sm focus:ring-2 focus:ring-[#014582] focus:border-transparent outline-none bg-white" />
                </div>
              </div>
              <div className="bg-gray-50 rounded-lg p-3 md:p-4 border border-gray-200">
                <h4 className="text-xs md:text-sm font-semibold text-gray-700 mb-2 md:mb-3">Warranty & Return</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 md:gap-4">
                  <div>
                    <label className="block text-xs md:text-sm font-semibold text-gray-700 mb-1.5">Warranty Period</label>
                    <input type="number" placeholder="12" value={formData.warrantyPeriod} onChange={(e) => handleInputChange('warrantyPeriod', e.target.value)} className="w-full px-3 md:px-4 py-1.5 md:py-2.5 border border-gray-200 rounded-lg text-xs md:text-sm focus:ring-2 focus:ring-[#014582] focus:border-transparent outline-none bg-gray-50" />
                  </div>
                  <div>
                    <label className="block text-xs md:text-sm font-semibold text-gray-700 mb-1.5">Warranty Unit</label>
                    <select value={formData.warrantyUnit} onChange={(e) => handleInputChange('warrantyUnit', e.target.value)} className="w-full px-3 md:px-4 py-1.5 md:py-2.5 border border-gray-200 rounded-lg text-xs md:text-sm focus:ring-2 focus:ring-[#014582] focus:border-transparent outline-none bg-gray-50">
                      <option>Days</option><option>Months</option><option>Years</option>
                    </select>
                  </div>
                  <div className="flex items-center gap-3">
                    <input type="checkbox" checked={formData.isReturnable} onChange={(e) => handleInputChange('isReturnable', e.target.checked)} className="w-4 h-4 text-[#014582] rounded border-gray-300" />
                    <label className="text-xs md:text-sm font-medium text-gray-700">Is Returnable</label>
                  </div>
                  <div>
                    <label className="block text-xs md:text-sm font-semibold text-gray-700 mb-1.5">Return Days</label>
                    <input type="number" placeholder="7" value={formData.returnDays} onChange={(e) => handleInputChange('returnDays', e.target.value)} className="w-full px-3 md:px-4 py-1.5 md:py-2.5 border border-gray-200 rounded-lg text-xs md:text-sm focus:ring-2 focus:ring-[#014582] focus:border-transparent outline-none bg-gray-50" />
                  </div>
                </div>
              </div>
              <div className="bg-gray-50 rounded-lg p-3 md:p-4 border border-gray-200">
                <h4 className="text-xs md:text-sm font-semibold text-gray-700 mb-2 md:mb-3">Additional Notes</h4>
                <textarea placeholder="Enter any additional notes..." rows={3} className="w-full px-3 md:px-4 py-1.5 md:py-2 border border-gray-200 rounded-lg text-xs md:text-sm focus:ring-2 focus:ring-[#014582] focus:border-transparent outline-none bg-white resize-none" />
              </div>
            </div>
          )}

          {/* FORM ACTIONS */}
          <div className="flex flex-col sm:flex-row items-center justify-end gap-2 sm:gap-3 pt-3 md:pt-4 border-t border-gray-100">
            <button type="button" onClick={onCancel} className="w-full sm:w-auto px-4 md:px-6 py-2 md:py-2.5 border border-gray-200 rounded-lg text-xs md:text-sm font-medium text-gray-600 hover:bg-gray-50 transition-all">
              Cancel
            </button>
            <button type="submit" disabled={loading} className="w-full sm:w-auto px-4 md:px-6 py-2 md:py-2.5 bg-[#014582] text-white rounded-lg text-xs md:text-sm font-semibold hover:bg-[#01366a] transition-all flex items-center justify-center gap-2 shadow-lg shadow-[#014582]/25 disabled:opacity-50 disabled:cursor-not-allowed">
              {loading ? <Loader2 className="w-3.5 h-3.5 md:w-4 md:h-4 animate-spin" /> : <Save className="w-3.5 h-3.5 md:w-4 md:h-4" />}
              {isEditing ? 'Update Product' : 'Save Product'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

// ============================================================
// MAIN PAGE
// ============================================================
export default function ProductsPage() {
  const { selectedLocationId, selectedLocation } = useLocation();
  const [allProducts, setAllProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [pagination, setPagination] = useState({
    page: 1, limit: 20, total: 0, pages: 0, hasNext: false, hasPrev: false,
  });
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedStatus, setSelectedStatus] = useState('all'); // full catalog; stock qty is per location
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [viewingProduct, setViewingProduct] = useState<Product | null>(null);
  const [showScanner, setShowScanner] = useState(false);
  const [categories, setCategories] = useState<Category[]>([]);
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);
  const [settingsData, setSettingsData] = useState<Record<string, any[]>>({});
  const [loadingSettings, setLoadingSettings] = useState(false);

  const fetchSettings = useCallback(async () => {
    setLoadingSettings(true);
    try {
      const cats = ['productType', 'rackLocation', 'zone', 'weightUnit', 'dimensionUnit', 'size', 'shippingClass', 'stockUnit', 'taxType', 'storageCondition'];
      const results = await Promise.all(cats.map(cat => settingService.getSettings(cat)));
      const map: Record<string, any[]> = {};
      cats.forEach((cat, idx) => { map[cat] = results[idx] || []; });
      setSettingsData(map);
    } catch (err) {
      console.error('Failed to fetch settings:', err);
    } finally {
      setLoadingSettings(false);
    }
  }, []);

  useEffect(() => {
    const fetchDropdowns = async () => {
      try {
        const [cats, supps] = await Promise.all([
          // Flat list: parents + children with parentId (needed for subcategory filter)
          categoryService.getCategories({ tree: false }),
          supplierService.getSuppliers({ limit: 100 }),
        ]);

        const flat = (Array.isArray(cats) ? cats : [])
          .map((c) => ({
            ...c,
            id: c.id || (c as any)._id || '',
            parentId: c.parentId ?? null,
          }))
          .filter((c) => !!c.id);

        setCategories(flat);
        setSuppliers(supps?.data || []);
      } catch (err) {
        console.error('Failed to fetch dropdowns:', err);
      }
    };
    fetchDropdowns();
    fetchSettings();
  }, [fetchSettings]);

  const fetchProducts = useCallback(async () => {
    if (!selectedLocationId) return;
    console.log('🔵 [fetchProducts] Starting fetch', {
      selectedLocationId,
      searchTerm,
    });
    setLoading(true);
    try {
      // Load location stock for all products; category/status filtered client-side
      const result = await productService.getProducts({
        page: 1,
        limit: 500,
        search: searchTerm || undefined,
        locationId: selectedLocationId,
      });
      console.log('🔵 [fetchProducts] Received', result.data.length, 'products');
      setAllProducts(result.data);
    } catch (error: any) {
      console.error('❌ [fetchProducts] Failed to fetch products:', error);
      alert(error.message || 'Failed to load products');
      setAllProducts([]);
    } finally {
      setLoading(false);
    }
  }, [searchTerm, selectedLocationId]);

  useEffect(() => {
    fetchProducts();
  }, [fetchProducts]);

  // Client-side category + status filter (reliable; uses location-overlaid stock)
  const filteredProducts = useMemo(() => {
    let list = allProducts;

    if (selectedCategory !== 'all') {
      const childIds = categories
        .filter((c) => String(c.parentId || '') === String(selectedCategory))
        .map((c) => String(c.id || ''));
      const allowed = new Set(
        [String(selectedCategory), ...childIds].filter(Boolean)
      );
      list = list.filter((p) => allowed.has(String(p.categoryId || '')));
    }

    if (selectedStatus === 'in') {
      list = list.filter((p) => Number(p.currentStock || 0) > 0);
    } else if (selectedStatus === 'out') {
      list = list.filter((p) => Number(p.currentStock || 0) === 0);
    } else if (selectedStatus === 'low') {
      list = list.filter((p) => {
        const qty = Number(p.currentStock || 0);
        const min = Number(p.minimumStock || 5);
        return qty > 0 && qty <= min;
      });
    }

    return list;
  }, [allProducts, selectedCategory, selectedStatus, categories]);

  const pageSize = 20;
  const totalPages = Math.max(1, Math.ceil(filteredProducts.length / pageSize));
  const currentPage = Math.min(pagination.page, totalPages);
  const pagedProducts = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return filteredProducts.slice(start, start + pageSize);
  }, [filteredProducts, currentPage]);

  const listPagination = useMemo(
    () => ({
      page: currentPage,
      limit: pageSize,
      total: filteredProducts.length,
      pages: totalPages,
      hasNext: currentPage < totalPages,
      hasPrev: currentPage > 1,
    }),
    [currentPage, filteredProducts.length, totalPages]
  );

  useEffect(() => {
    setPagination((prev) => ({ ...prev, page: 1 }));
  }, [selectedLocationId]);

  useEffect(() => {
    setPagination((prev) => ({ ...prev, page: 1 }));
  }, [selectedCategory, selectedStatus, searchTerm]);

  const handleBarcodeScan = useCallback(async (scannedValue: string) => {
    setShowScanner(false);
    setLoading(true);
    try {
      const result = await productService.getProducts({
        search: scannedValue,
        limit: 1,
        locationId: selectedLocationId || undefined,
      });
      if (result.data.length > 0) {
        setViewingProduct(result.data[0]);
      } else {
        alert(`No product found for barcode: ${scannedValue}`);
      }
    } catch (err: any) {
      alert(err.message || 'Scan failed');
    } finally {
      setLoading(false);
    }
  }, [selectedLocationId]);

  const handlePageChange = (page: number) =>
    setPagination((prev) => ({ ...prev, page }));
  const handleSearch = (val: string) => {
    setSearchTerm(val);
  };
  const handleCategoryChange = (val: string) => {
    setSelectedCategory(val);
  };
  const handleStatusChange = (val: string) => {
    setSelectedStatus(val);
  };

  const handleAddClick = () => { setEditingProduct(null); setShowCreateForm(true); };

  const handleViewClick = async (product: Product) => {
    const id = getProductId(product);
    if (!id) {
      setViewingProduct(product);
      return;
    }
    try {
      setViewingProduct(await productService.getProductById(id));
    } catch {
      setViewingProduct(product);
    }
  };

  const handleEditClick = async (product: Product) => {
    setViewingProduct(null);
    const id = getProductId(product);
    if (!id) {
      setEditingProduct(product);
      setShowCreateForm(true);
      return;
    }
    try {
      setEditingProduct(await productService.getProductById(id));
    } catch {
      setEditingProduct(product);
    }
    setShowCreateForm(true);
  };
  const handleDeleteClick = async (id: string) => {
    console.log('🔵 [handleDeleteClick] Starting delete for product ID:', id);
    if (!confirm('Delete this product?')) {
      console.log('🔵 [handleDeleteClick] Delete cancelled by user');
      return;
    }
    try {
      console.log('🔵 [handleDeleteClick] Calling productService.deleteProduct');
      await productService.deleteProduct(id);
      console.log('✅ [handleDeleteClick] Delete successful, refreshing products');
      fetchProducts();
    }
    catch (error: any) {
      console.error('❌ [handleDeleteClick] Delete failed:', error);
      alert(error.message || 'Failed to delete product');
    }
  };
  const handleFormSuccess = () => {
    setShowCreateForm(false);
    setEditingProduct(null);
    setSelectedStatus('all'); // new product has 0 stock — must show in catalog
    setPagination((prev) => ({ ...prev, page: 1 }));
    fetchProducts();
  };

  return (
    <div className="space-y-4 md:space-y-6">
      {selectedLocation && (
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 px-3 py-2 rounded-lg bg-sky-50 border border-sky-100 text-sm text-sky-800">
          <div className="flex items-center gap-2">
            <MapPin className="w-4 h-4 flex-shrink-0" />
            <span>
              Products for <strong>{selectedLocation.name}</strong>
              <span className="text-sky-600 font-mono text-xs ml-1">({selectedLocation.code})</span>
              {' · '}
              only products assigned to this location
              {selectedStatus === 'in' ? ' · In Stock' : ''}
              {selectedStatus === 'out' ? ' · Out of Stock' : ''}
              {selectedStatus === 'low' ? ' · Low Stock' : ''}
            </span>
          </div>
        </div>
      )}

      {showScanner && (
        <BarcodeScanner
          onScan={handleBarcodeScan}
          onClose={() => setShowScanner(false)}
        />
      )}

      {viewingProduct && (
        <ProductDetail
          product={viewingProduct}
          onClose={() => setViewingProduct(null)}
          onEdit={() => handleEditClick(viewingProduct)}
        />
      )}

      {showCreateForm ? (
        <ProductForm
          editingProduct={editingProduct}
          onCancel={() => { setShowCreateForm(false); setEditingProduct(null); }}
          onSuccess={handleFormSuccess}
          categories={categories}
          suppliers={suppliers}
          settingsData={settingsData}
          loadingSettings={loadingSettings}
          locationId={selectedLocationId}
          onCategoryCreated={(cat) => {
            setCategories((prev) => {
              if (prev.some((c) => String(c.id) === String(cat.id))) return prev;
              return [...prev, cat];
            });
          }}
          onSupplierCreated={(sup) => {
            setSuppliers((prev) => {
              const id = String((sup as any).id || (sup as any)._id || '');
              if (prev.some((s) => String((s as any).id || (s as any)._id) === id)) {
                return prev;
              }
              return [...prev, sup];
            });
          }}
          onSettingCreated={(cat, item) => {
            setSettingsData((prev) => {
              const list = prev[cat] || [];
              const name = item?.name;
              if (name && list.some((x) => x.name === name)) return prev;
              return { ...prev, [cat]: [...list, item] };
            });
          }}
        />
      ) : (
        <ProductList
          products={pagedProducts}
          loading={loading}
          pagination={listPagination}
          searchTerm={searchTerm}
          setSearchTerm={handleSearch}
          selectedCategory={selectedCategory}
          setSelectedCategory={handleCategoryChange}
          selectedStatus={selectedStatus}
          setSelectedStatus={handleStatusChange}
          onPageChange={handlePageChange}
          onAddClick={handleAddClick}
          onEditClick={handleEditClick}
          onDeleteClick={handleDeleteClick}
          onViewClick={handleViewClick}
          onScanClick={() => setShowScanner(true)}
          categories={categories}
          locationName={selectedLocation?.name}
        />
      )}
    </div>
  );
}